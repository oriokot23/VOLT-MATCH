import { Radio, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useVoltStore } from "@/lib/store";

export function Header({ onRetry }: { onRetry: () => void }) {
  const status = useVoltStore((s) => s.status);
  const bank = useVoltStore((s) => s.bank);
  const live = status.mode === "live";
  const sim = status.mode === "simulated";

  return (
    <header className="flex items-center gap-3 border-b border-border px-4 py-3 sm:px-6">
      <Mark />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <h1 className="truncate text-sm font-semibold tracking-[0.18em] text-fg">VOLTMATCH</h1>
          <span className="hidden text-xs text-muted sm:inline">Digit Match AI</span>
        </div>
        <p className="truncate text-2xs text-subtle sm:text-xs">{status.detail}</p>
      </div>
      <div
        className={cn(
          "inline-flex h-9 items-center gap-2 rounded-full border px-3 text-xs font-medium",
          live && "border-live/30 bg-live/10 text-live",
          sim && "border-border bg-elevated text-muted",
          status.mode === "connecting" && "border-border bg-elevated text-muted",
        )}
      >
        <Radio className={cn("size-3.5", live && "live-dot text-live")} />
        {live ? "Live Deriv" : sim ? "Local stream" : "Connecting"}
      </div>
      {sim ? (
        <Button variant="ghost" size="sm" onClick={onRetry} className="hidden sm:inline-flex">
          <RotateCcw />
          Retry live
        </Button>
      ) : null}
      <div className="hidden tabular-nums text-right sm:block">
        <p className="text-2xs uppercase tracking-wider text-subtle">Paper bank</p>
        <p className="font-mono text-sm text-fg">{formatMoney(bank)}</p>
      </div>
    </header>
  );
}

function Mark() {
  return (
    <span
      className="flex size-10 items-center justify-center rounded-[var(--radius-md)] border border-border bg-elevated"
      aria-hidden="true"
    >
      <svg viewBox="0 0 24 24" className="size-5 text-accent" fill="none">
        <path d="M4 18 L10 6 L13 12" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
        <path d="M13 12 L16 7 L20 18" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
        <circle cx="16" cy="7" r="1.4" fill="currentColor" className="text-live" />
      </svg>
    </span>
  );
}

export function formatMoney(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  }).format(n);
}
