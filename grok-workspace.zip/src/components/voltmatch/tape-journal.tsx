import { getIndex } from "@/lib/deriv/symbols";
import { useVoltStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { formatMoney } from "./header";

export function TickTape({ digits }: { digits: number[] }) {
  const shown = digits.slice(-36);
  return (
    <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-medium text-fg">Tick tape</h3>
        <p className="text-2xs text-subtle">Newest on the right</p>
      </div>
      <div className="flex flex-wrap justify-end gap-1 font-mono text-sm tabular-nums">
        {shown.length === 0 ? (
          <span className="text-muted">Waiting for ticks…</span>
        ) : (
          shown.map((d, i) => (
            <span
              key={`${i}-${d}`}
              className={cn(
                "flex size-8 items-center justify-center rounded-[var(--radius-sm)] bg-elevated",
                i === shown.length - 1 ? "bg-live/15 text-live" : "text-fg",
              )}
            >
              {d}
            </span>
          ))
        )}
      </div>
    </section>
  );
}

export function Journal() {
  const journal = useVoltStore((s) => s.journal);
  const resetBank = useVoltStore((s) => s.resetBank);
  const wins = journal.filter((t) => t.won).length;
  const recent = [...journal].reverse().slice(0, 12);

  return (
    <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-medium text-fg">Paper journal</h3>
          <p className="text-xs text-muted">
            {journal.length === 0
              ? "No settled calls yet"
              : `${wins}/${journal.length} hits · ${((wins / journal.length) * 100).toFixed(0)}%`}
          </p>
        </div>
        <button type="button" onClick={resetBank} className="text-xs text-muted hover:text-fg">
          Reset bank
        </button>
      </div>
      {recent.length === 0 ? (
        <p className="text-sm text-muted">Arm a digit on the pad. The next tick on that index settles it.</p>
      ) : (
        <ul className="flex flex-col gap-1.5">
          {recent.map((t) => (
            <li
              key={t.id}
              className="flex items-center gap-2 rounded-[var(--radius-md)] border border-border bg-elevated px-3 py-2 text-xs"
            >
              <span className={cn("font-mono tabular-nums", t.won ? "text-win" : "text-loss")}>
                {t.won ? "WIN" : "LOSS"}
              </span>
              <span className="min-w-0 flex-1 truncate text-muted">{getIndex(t.symbol).short}</span>
              <span className="font-mono tabular-nums text-fg">
                {t.called}→{t.actual}
              </span>
              <span className={cn("font-mono tabular-nums", t.pnl >= 0 ? "text-win" : "text-loss")}>
                {t.pnl >= 0 ? "+" : ""}
                {formatMoney(t.pnl)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
