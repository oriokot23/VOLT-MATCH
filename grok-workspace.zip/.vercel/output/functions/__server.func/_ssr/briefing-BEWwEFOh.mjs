import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as array } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/briefing-BEWwEFOh.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var BriefingInput = object({
	name: string().max(80),
	symbol: string().max(20),
	strategy: string().max(20),
	window: number().int().min(10).max(2e3),
	lastDigit: number().int().min(0).max(9),
	pick: number().int().min(0).max(9),
	confidence: string().max(20),
	percents: array(number()).length(10),
	gaps: array(number()).length(10),
	chiLabel: string().max(40),
	recent: array(number().int().min(0).max(9)).max(60)
});
var lastCallAt = 0;
var requestBriefing_createServerFn_handler = createServerRpc({
	id: "31c1c2020cadfe9a7484ebb54b4c3570b96ddc4675bec251c52c6fa88e963852",
	name: "requestBriefing",
	filename: "src/lib/ai/briefing.ts"
}, (opts) => requestBriefing.__executeServer(opts));
var requestBriefing = createServerFn({ method: "POST" }).validator((input) => BriefingInput.parse(input)).handler(requestBriefing_createServerFn_handler, async ({ data }) => {
	const now = Date.now();
	if (now - lastCallAt < 12e3) return {
		ok: false,
		error: "Wait a few seconds before another briefing."
	};
	lastCallAt = now;
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI briefing is unavailable in this environment."
	};
	const freq = data.percents.map((p, d) => `${d}:${p.toFixed(1)}%`).join("  ");
	const gaps = data.gaps.map((g, d) => `${d}:${g}`).join("  ");
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 320,
			temperature: .3,
			messages: [{
				role: "system",
				content: "You analyse Deriv synthetic-index last digits for Digit Match contracts. Be precise, sober, and short. Never promise profit. Never use emoji. Last digits are designed to sit near a 10% base rate; any lean is a window artefact, not a tradable edge. 4–6 sentences max."
			}, {
				role: "user",
				content: [
					`Index: ${data.name} (${data.symbol})`,
					`Strategy: ${data.strategy} · window ${data.window} ticks`,
					`Last digit: ${data.lastDigit} · model pick: ${data.pick} · confidence: ${data.confidence}`,
					`Uniformity: ${data.chiLabel}`,
					`Frequencies: ${freq}`,
					`Gaps (ticks since last): ${gaps}`,
					`Recent tape: ${data.recent.join("")}`,
					"Explain what the window shows, why the pick was ranked first under that strategy, what would falsify it, and a one-line risk reminder."
				].join("\n")
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Briefing failed (${res.status}).`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty briefing."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { requestBriefing_createServerFn_handler };
