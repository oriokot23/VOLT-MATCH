import type { DigitStats, Signal } from "@/lib/analysis";
import { cn } from "@/lib/utils";

export function DigitBoard({
  stats,
  signal,
  lastDigit,
  selected,
  armedDigit,
  flashDigit,
  onSelect,
}: {
  stats: DigitStats;
  signal: Signal;
  lastDigit: number | null;
  selected: number | null;
  armedDigit: number | null;
  flashDigit: number | null;
  onSelect: (digit: number) => void;
}) {
  const pick = signal.primary.digit;
  const maxPct = Math.max(12, ...stats.percents);

  return (
    <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
      <div className="mb-3 flex items-end justify-between">
        <div>
          <h3 className="text-sm font-medium text-fg">Digit pad</h3>
          <p className="text-xs text-muted">Tap a digit, then call the next tick</p>
        </div>
        <p className="text-xs tabular-nums text-subtle">{stats.n} tick window</p>
      </div>
      <div className="grid grid-cols-5 gap-2">
        {Array.from({ length: 10 }, (_, digit) => {
          const pct = stats.percents[digit] ?? 0;
          const gap = stats.gaps[digit] ?? 0;
          const isPick = pick === digit;
          const isSel = selected === digit;
          const isArmed = armedDigit === digit;
          const isFlash = flashDigit === digit;
          const bar = Math.min(100, (pct / maxPct) * 100);
          return (
            <button
              key={digit}
              type="button"
              onClick={() => onSelect(digit)}
              className={cn(
                "relative flex h-[4.75rem] flex-col items-center justify-center overflow-hidden rounded-[var(--radius-md)] border bg-elevated px-1 pt-1",
                isSel || isArmed ? "border-accent text-fg" : "border-border text-fg",
                isPick && !isSel && "ring-1 ring-live/50",
                isFlash && "cell-flash",
              )}
            >
              <span className="font-mono text-xl font-medium tabular-nums leading-none">{digit}</span>
              <span className="mt-1 font-mono text-2xs tabular-nums text-muted">{pct.toFixed(1)}%</span>
              <span className="text-2xs tabular-nums text-subtle">gap {gap}</span>
              <span
                className="pointer-events-none absolute inset-x-1 bottom-1 h-0.5 rounded-full bg-border"
                aria-hidden="true"
              >
                <span
                  className={cn("block h-full rounded-full", isPick ? "bg-live" : "bg-accent/70")}
                  style={{ width: `${bar}%` }}
                />
              </span>
              {isPick ? (
                <span className="absolute right-1 top-1 text-2xs uppercase tracking-wide text-live">AI</span>
              ) : null}
            </button>
          );
        })}
      </div>
      {lastDigit != null ? (
        <p className="mt-3 text-xs text-muted">
          Last print <span className="font-mono text-fg">{lastDigit}</span>
          <span className="text-subtle"> · even/odd {stats.even}/{stats.odd} · over/under {stats.over}/{stats.under}</span>
        </p>
      ) : (
        <p className="mt-3 text-xs text-muted">Waiting for ticks…</p>
      )}
    </section>
  );
}
