import { createFileRoute } from "@tanstack/react-router";
import { VoltmatchApp } from "@/components/voltmatch/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <VoltmatchApp />;
}
