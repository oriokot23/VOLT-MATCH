import { useEffect, useState } from "react";
import { Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useDerivFeed } from "@/lib/use-feed";
import { usePrimaryAnalysis } from "@/lib/use-analysis";
import { useVoltStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Header } from "./header";
import { IndexRail } from "./index-rail";
import { QuoteStage } from "./quote-stage";
import { DigitBoard } from "./digit-board";
import { SignalDesk } from "./signal-desk";
import { Scanner } from "./scanner";
import { TickTape, Journal } from "./tape-journal";
import { FreqChart } from "./freq-chart";

export function VoltmatchApp() {
  const { retryLive } = useDerivFeed();
  const { stats, signal, last, digits } = usePrimaryAnalysis();
  const symbol = useVoltStore((s) => s.symbol);
  const setSymbol = useVoltStore((s) => s.setSymbol);
  const armed = useVoltStore((s) => s.armed);
  const flashEpoch = useVoltStore((s) => s.flashEpoch);
  const [selected, setSelected] = useState<number | null>(null);
  const [tab, setTab] = useState<"desk" | "scanner" | "journal">("desk");

  useEffect(() => {
    setSelected(null);
  }, [symbol]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      if (e.key >= "0" && e.key <= "9") setSelected(Number(e.key));
      if (e.key === "Enter") {
        useVoltStore.getState().arm(selected ?? signal.primary.digit);
      }
      if (e.key === "Escape") useVoltStore.getState().disarm();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selected, signal.primary.digit]);

  const pick = selected ?? signal.primary.digit;
  const arm = useVoltStore((s) => s.arm);
  const bank = useVoltStore((s) => s.bank);
  const stake = useVoltStore((s) => s.stake);

  return (
    <div className="flex min-h-dvh flex-col overflow-x-hidden bg-bg">
      <Header onRetry={retryLive} />
      <div className="flex flex-1 flex-col lg:flex-row">
        <IndexRail />
        <main className="flex min-w-0 flex-1 flex-col gap-3 p-4 sm:p-5">
          <div className="flex gap-1 rounded-[var(--radius-md)] bg-elevated p-1 lg:hidden">
            {(
              [
                ["desk", "Desk"],
                ["scanner", "Scanner"],
                ["journal", "Journal"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={cn(
                  "h-10 flex-1 rounded-[var(--radius-sm)] text-sm font-medium",
                  tab === id ? "bg-accent text-accent-fg" : "text-muted",
                )}
              >
                {label}
              </button>
            ))}
          </div>

          <div className={cn(tab === "desk" ? "block" : "hidden", "lg:block")}>
            <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
              <div className="flex flex-col gap-3">
                <QuoteStage tick={last} symbol={symbol} />
                <div className="flex items-center gap-3 rounded-[var(--radius-xl)] border border-border bg-surface p-3 xl:hidden">
                  <div className="min-w-0 flex-1">
                    <p className="text-2xs uppercase tracking-[0.16em] text-subtle">Match call</p>
                    <p className="font-mono text-2xl font-medium tabular-nums text-fg">{pick}</p>
                  </div>
                  <Button
                    size="sm"
                    disabled={!!armed || stake > bank || !last}
                    onClick={() => arm(pick)}
                  >
                    <Target />
                    {armed ? `Armed ${armed.digit}` : `Call ${pick}`}
                  </Button>
                </div>
                <DigitBoard
                  stats={stats}
                  signal={signal}
                  lastDigit={last?.digit ?? null}
                  selected={pick}
                  armedDigit={armed?.digit ?? null}
                  flashDigit={last && last.epoch === flashEpoch ? last.digit : null}
                  onSelect={setSelected}
                />
                <FreqChart stats={stats} signal={signal} />
                <TickTape digits={digits} />
                <div className="hidden lg:block">
                  <Scanner onOpen={setSymbol} />
                </div>
              </div>
              <SignalDesk
                stats={stats}
                signal={signal}
                lastDigit={last?.digit ?? null}
                recent={digits}
                selected={pick}
                onSelect={setSelected}
              />
            </div>
          </div>

          <div className={cn(tab === "scanner" ? "block" : "hidden", "lg:hidden")}>
            <Scanner
              onOpen={(next) => {
                setSymbol(next);
                setTab("desk");
              }}
            />
          </div>

          <div className={cn(tab === "journal" ? "block" : "hidden", "lg:block")}>
            <Journal />
          </div>

          <p className="pb-4 pt-2 text-2xs leading-relaxed text-subtle">
            Voltmatch reads last digits from Deriv volatility ticks and ranks Digit Match calls with
            due, hot, path, and blend models. Synthetic indices are designed to be near-fair. Nothing
            here is a trading signal with positive expected value, financial advice, or a connection
            to a Deriv account. You can lose money on Digit Match.
          </p>
        </main>
      </div>
    </div>
  );
}
