import { splitQuote, type Tick } from "@/lib/deriv/digits";
import { getIndex } from "@/lib/deriv/symbols";
import { useVoltStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const EMPTY: Tick[] = [];

export function QuoteStage({
  tick,
  symbol,
}: {
  tick: Tick | null;
  symbol: string;
}) {
  const index = getIndex(symbol);
  const parts = tick ? splitQuote(tick) : { head: "—", tail: "" };
  const sparkTicks = useVoltStore((s) => s.ticksBySymbol[symbol] ?? EMPTY);

  return (
    <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-2xs font-medium uppercase tracking-[0.16em] text-subtle">
            {index.group === "1s" ? "1s index" : "2s index"} · {index.volatility}% vol
          </p>
          <h2 className="mt-1 text-lg font-medium tracking-tight text-fg">{index.name}</h2>
        </div>
        <Sparkline ticks={sparkTicks.slice(-80)} />
      </div>

      <div className="mt-4 flex items-end justify-between gap-4">
        <p className="font-mono text-xl tabular-nums text-muted sm:text-2xl">
          <span>{parts.head}</span>
          <span className="text-live">{parts.tail}</span>
        </p>
        <div className="text-right">
          <p className="text-2xs uppercase tracking-[0.16em] text-subtle">Last digit</p>
          <p
            key={tick?.epoch ?? "empty"}
            className={cn(
              "digit-pop font-mono text-5xl font-medium leading-none tabular-nums text-fg sm:text-5xl",
            )}
          >
            {tick ? tick.digit : "–"}
          </p>
        </div>
      </div>
    </section>
  );
}

function Sparkline({ ticks }: { ticks: Tick[] }) {
  if (ticks.length < 2) {
    return <div className="h-10 w-28" />;
  }
  const values = ticks.map((t) => t.quote);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const w = 112;
  const h = 40;
  const d = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * w;
      const y = h - ((v - min) / span) * (h - 4) - 2;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-10 w-28 text-live" aria-hidden="true">
      <path d={d} fill="none" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}
