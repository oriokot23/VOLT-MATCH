import { useMemo } from "react";
import { analyze, scoreDigits } from "@/lib/analysis";
import { VOLATILITY_INDICES } from "@/lib/deriv/symbols";
import { useVoltStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Scanner({ onOpen }: { onOpen: (symbol: string) => void }) {
  const lastBySymbol = useVoltStore((s) => s.lastBySymbol);
  const ticksBySymbol = useVoltStore((s) => s.ticksBySymbol);
  const active = useVoltStore((s) => s.symbol);
  const strategy = useVoltStore((s) => s.strategy);

  const rows = useMemo(() => {
    return VOLATILITY_INDICES.map((idx) => {
      const ticks = ticksBySymbol[idx.symbol] ?? [];
      const digits = ticks.slice(-100).map((t) => t.digit);
      const stats = analyze(digits);
      const signal = scoreDigits(stats, digits, strategy);
      const last = lastBySymbol[idx.symbol];
      const strength = Math.min(100, Math.round((signal.primary.weight - 0.1) * 900));
      return { idx, last, pick: signal.primary.digit, strength: Math.max(0, strength), chi: stats.chiLabel };
    });
  }, [lastBySymbol, ticksBySymbol, strategy]);

  return (
    <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h3 className="text-sm font-medium text-fg">All volatility indices</h3>
          <p className="text-xs text-muted">Live last digit and match lean across the full book</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {rows.map((row) => {
          const on = row.idx.symbol === active;
          return (
            <button
              key={row.idx.symbol}
              type="button"
              onClick={() => onOpen(row.idx.symbol)}
              className={cn(
                "flex items-center gap-3 rounded-[var(--radius-lg)] border px-3 py-2.5 text-left",
                on ? "border-accent/40 bg-elevated" : "border-border bg-elevated/60 hover:bg-elevated",
              )}
            >
              <span className="flex size-11 items-center justify-center rounded-[var(--radius-md)] bg-surface font-mono text-xl tabular-nums text-fg">
                {row.last ? row.last.digit : "–"}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium text-fg">{row.idx.short}</span>
                <span className="block truncate text-2xs text-subtle">{row.idx.name}</span>
              </span>
              <span className="text-right">
                <span className="block font-mono text-sm tabular-nums text-live">→ {row.pick}</span>
                <span className="block text-2xs tabular-nums text-subtle">{row.strength}</span>
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
