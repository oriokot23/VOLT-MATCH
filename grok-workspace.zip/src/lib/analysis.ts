export type Strategy = "due" | "hot" | "markov" | "ensemble";

export const STRATEGIES: { id: Strategy; label: string; hint: string }[] = [
  { id: "due", label: "Due", hint: "Under-printed and overdue digits" },
  { id: "hot", label: "Hot", hint: "Recently frequent digits" },
  { id: "markov", label: "Path", hint: "What usually follows the last digit" },
  { id: "ensemble", label: "Blend", hint: "Due + path + a touch of heat" },
];

export type DigitStats = {
  n: number;
  counts: number[];
  percents: number[];
  zScores: number[];
  gaps: number[];
  even: number;
  odd: number;
  over: number;
  under: number;
  chiSquare: number;
  chiLabel: string;
  markov: number[][];
};

export type DigitCall = {
  digit: number;
  weight: number;
  score: number;
  reasons: string[];
};

export type Signal = {
  primary: DigitCall;
  ranked: DigitCall[];
  confidence: "Low" | "Mild" | "Moderate";
  confidenceNote: string;
  differsDigit: number;
};

const EMPTY_COUNTS = () => Array.from({ length: 10 }, () => 0);

export function analyze(digits: number[]): DigitStats {
  const counts = EMPTY_COUNTS();
  const lastSeen = Array.from({ length: 10 }, () => -1);
  const markov = Array.from({ length: 10 }, () => EMPTY_COUNTS());
  let even = 0;
  let over = 0;

  for (let i = 0; i < digits.length; i++) {
    const d = digits[i]!;
    if (d < 0 || d > 9) continue;
    counts[d]! += 1;
    lastSeen[d] = i;
    if (d % 2 === 0) even += 1;
    if (d > 4) over += 1;
    if (i > 0) {
      const prev = digits[i - 1]!;
      if (prev >= 0 && prev <= 9) markov[prev]![d]! += 1;
    }
  }

  const n = digits.length;
  const expected = n / 10;
  const denom = Math.sqrt(Math.max(n * 0.1 * 0.9, 1e-9));
  const percents = counts.map((c) => (n ? (c / n) * 100 : 0));
  const zScores = counts.map((c) => (c - expected) / denom);
  const gaps = lastSeen.map((idx) => (n === 0 ? 0 : idx < 0 ? n : n - 1 - idx));
  const chiSquare =
    n === 0
      ? 0
      : counts.reduce((sum, c) => sum + ((c - expected) ** 2) / Math.max(expected, 1e-9), 0);

  return {
    n,
    counts,
    percents,
    zScores,
    gaps,
    even,
    odd: n - even,
    over,
    under: n - over,
    chiSquare,
    chiLabel: chiLabel(chiSquare, n),
    markov,
  };
}

function chiLabel(chi: number, n: number): string {
  if (n < 50) return "Too little data";
  if (chi > 21.67) return "Skewed vs 10%";
  if (chi > 16.92) return "Mild skew";
  return "Close to uniform";
}

function softmax(values: number[], temperature = 0.85): number[] {
  const max = Math.max(...values);
  const exps = values.map((v) => Math.exp((v - max) / temperature));
  const sum = exps.reduce((a, b) => a + b, 0) || 1;
  return exps.map((e) => e / sum);
}

function dueScores(stats: DigitStats): number[] {
  const gapDen = Math.sqrt(10 * 0.9);
  return stats.zScores.map((z, d) => {
    const under = -z;
    const overdue = (stats.gaps[d]! - 10) / gapDen;
    return 0.58 * under + 0.42 * overdue;
  });
}

function hotScores(stats: DigitStats, recent: number[]): number[] {
  const recCounts = EMPTY_COUNTS();
  for (const d of recent) if (d >= 0 && d <= 9) recCounts[d]! += 1;
  const recN = Math.max(recent.length, 1);
  return stats.zScores.map((z, d) => 0.55 * z + 0.45 * (recCounts[d]! / recN - 0.1) * 10);
}

function markovScores(stats: DigitStats, last: number | null): number[] {
  if (last == null || last < 0 || last > 9) return Array.from({ length: 10 }, () => 0);
  const row = stats.markov[last]!;
  const rowN = row.reduce((a, b) => a + b, 0);
  if (rowN < 8) return Array.from({ length: 10 }, () => 0);
  return row.map((c) => (c / rowN - 0.1) * 8);
}

function blend(a: number[], b: number[], wa: number, wb: number): number[] {
  return a.map((v, i) => wa * v + wb * (b[i] ?? 0));
}

function reasonList(
  digit: number,
  stats: DigitStats,
  last: number | null,
  strategy: Strategy,
): string[] {
  const reasons: string[] = [];
  const expected = stats.n / 10;
  const count = stats.counts[digit]!;
  const gap = stats.gaps[digit]!;
  const pct = stats.percents[digit]!;

  if (strategy === "due" || strategy === "ensemble") {
    if (count < expected - 0.4) {
      reasons.push(
        `${digit} printed ${count}× vs ${expected.toFixed(1)} expected in this window (${pct.toFixed(1)}%).`,
      );
    }
    if (gap >= 16) reasons.push(`Last seen ${gap} ticks ago — overdue vs ~10 tick mean gap.`);
  }
  if (strategy === "hot" || strategy === "ensemble") {
    if (count > expected + 0.8) {
      reasons.push(`${digit} is running hot at ${pct.toFixed(1)}% of the window.`);
    }
  }
  if ((strategy === "markov" || strategy === "ensemble") && last != null) {
    const row = stats.markov[last]!;
    const rowN = row.reduce((a, b) => a + b, 0);
    if (rowN >= 8) {
      const p = (row[digit]! / rowN) * 100;
      reasons.push(`After ${last}, ${digit} followed in ${row[digit]} of ${rowN} ticks (${p.toFixed(0)}%).`);
    }
  }
  if (reasons.length === 0) {
    reasons.push(`Weights are close to the 10% base rate — no strong structure in this window.`);
  }
  return reasons.slice(0, 3);
}

export function scoreDigits(
  stats: DigitStats,
  digits: number[],
  strategy: Strategy,
): Signal {
  const last = digits.length ? digits[digits.length - 1]! : null;
  const recent = digits.slice(-20);
  const due = dueScores(stats);
  const hot = hotScores(stats, recent);
  const path = markovScores(stats, last);

  let raw: number[];
  if (strategy === "due") raw = due;
  else if (strategy === "hot") raw = hot;
  else if (strategy === "markov") raw = path;
  else raw = blend(blend(due, path, 0.5, 0.3), hot, 1, 0.2);

  const weights = softmax(raw);
  const ranked: DigitCall[] = raw
    .map((score, digit) => ({
      digit,
      score,
      weight: weights[digit]!,
      reasons: reasonList(digit, stats, last, strategy),
    }))
    .sort((a, b) => b.weight - a.weight);

  const primary = ranked[0]!;
  const second = ranked[1]!;
  const spread = primary.weight - second.weight;
  const skewed = stats.n >= 50 && stats.chiSquare > 16.92;
  let confidence: Signal["confidence"] = "Low";
  if (spread > 0.045 && skewed) confidence = "Moderate";
  else if (spread > 0.03 || skewed) confidence = "Mild";

  const confidenceNote =
    confidence === "Low"
      ? "Near-fair dice. Any lean is small and can vanish on the next tick."
      : confidence === "Mild"
        ? "A modest lean vs 10%. Treat it as a lens, not an edge."
        : "Window is off-uniform and the top digit separates. Still not a house-beating edge.";

  return {
    primary,
    ranked,
    confidence,
    confidenceNote,
    differsDigit: ranked[ranked.length - 1]!.digit,
  };
}

export function evenOddLean(stats: DigitStats): { evenPct: number; oddPct: number } {
  if (!stats.n) return { evenPct: 50, oddPct: 50 };
  return { evenPct: (stats.even / stats.n) * 100, oddPct: (stats.odd / stats.n) * 100 };
}

export function overUnderLean(stats: DigitStats): { overPct: number; underPct: number } {
  if (!stats.n) return { overPct: 50, underPct: 50 };
  return { overPct: (stats.over / stats.n) * 100, underPct: (stats.under / stats.n) * 100 };
}
