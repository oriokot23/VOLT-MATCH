import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const BriefingInput = z.object({
  name: z.string().max(80),
  symbol: z.string().max(20),
  strategy: z.string().max(20),
  window: z.number().int().min(10).max(2000),
  lastDigit: z.number().int().min(0).max(9),
  pick: z.number().int().min(0).max(9),
  confidence: z.string().max(20),
  percents: z.array(z.number()).length(10),
  gaps: z.array(z.number()).length(10),
  chiLabel: z.string().max(40),
  recent: z.array(z.number().int().min(0).max(9)).max(60),
});

export type BriefingResult =
  | { ok: true; text: string }
  | { ok: false; error: string };

let lastCallAt = 0;

export const requestBriefing = createServerFn({ method: "POST" })
  .validator((input: unknown) => BriefingInput.parse(input))
  .handler(async ({ data }): Promise<BriefingResult> => {
    const now = Date.now();
    if (now - lastCallAt < 12_000) {
      return { ok: false, error: "Wait a few seconds before another briefing." };
    }
    lastCallAt = now;

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "AI briefing is unavailable in this environment." };

    const freq = data.percents
      .map((p, d) => `${d}:${p.toFixed(1)}%`)
      .join("  ");
    const gaps = data.gaps.map((g, d) => `${d}:${g}`).join("  ");

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 320,
        temperature: 0.3,
        messages: [
          {
            role: "system",
            content:
              "You analyse Deriv synthetic-index last digits for Digit Match contracts. Be precise, sober, and short. Never promise profit. Never use emoji. Last digits are designed to sit near a 10% base rate; any lean is a window artefact, not a tradable edge. 4–6 sentences max.",
          },
          {
            role: "user",
            content: [
              `Index: ${data.name} (${data.symbol})`,
              `Strategy: ${data.strategy} · window ${data.window} ticks`,
              `Last digit: ${data.lastDigit} · model pick: ${data.pick} · confidence: ${data.confidence}`,
              `Uniformity: ${data.chiLabel}`,
              `Frequencies: ${freq}`,
              `Gaps (ticks since last): ${gaps}`,
              `Recent tape: ${data.recent.join("")}`,
              "Explain what the window shows, why the pick was ranked first under that strategy, what would falsify it, and a one-line risk reminder.",
            ].join("\n"),
          },
        ],
      }),
    });

    if (!res.ok) return { ok: false, error: `Briefing failed (${res.status}).` };

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false, error: "Empty briefing." };
    return { ok: true, text };
  });
