import { lastDigit, type Tick } from "./digits";
import { ALL_SYMBOLS, getIndex, VOLATILITY_INDICES, type VolIndex } from "./symbols";

export type FeedMode = "connecting" | "live" | "simulated";

export type FeedStatus = {
  mode: FeedMode;
  detail: string;
};

export type FeedHandlers = {
  onStatus: (status: FeedStatus) => void;
  onTick: (tick: Tick) => void;
  onHistory: (symbol: string, ticks: Tick[]) => void;
};

const ENDPOINTS = [
  "wss://ws.derivws.com/websockets/v3?app_id=1089",
  "wss://ws.binaryws.com/websockets/v3?app_id=1089",
];

const LIVE_TIMEOUT_MS = 4500;
const HISTORY_COUNT = 800;
const TICK_CAP_SEED = 400;

type WsMsg = {
  msg_type?: string;
  error?: { message?: string };
  pip_size?: number;
  echo_req?: { ticks_history?: string; ticks?: string };
  history?: { prices?: number[]; times?: number[] };
  tick?: {
    quote?: number;
    epoch?: number;
    symbol?: string;
    pip_size?: number;
  };
};

export type DerivFeed = {
  start: (primary: string) => void;
  setPrimary: (symbol: string) => void;
  retryLive: () => void;
  stop: () => void;
};

export function createFeed(handlers: FeedHandlers): DerivFeed {
  let stopped = false;
  let ws: WebSocket | null = null;
  let pingTimer: ReturnType<typeof setInterval> | null = null;
  let simTimers: ReturnType<typeof setInterval>[] = [];
  let primary = ALL_SYMBOLS[0]!;
  let simPrices = new Map<string, number>();
  let reqSeq = 1;
  let pendingHistory = new Map<number, string>();
  let liveOpened = false;

  function setStatus(mode: FeedMode, detail: string) {
    handlers.onStatus({ mode, detail });
  }

  function clearPing() {
    if (pingTimer) {
      clearInterval(pingTimer);
      pingTimer = null;
    }
  }

  function stopSim() {
    for (const t of simTimers) clearInterval(t);
    simTimers = [];
  }

  function closeWs() {
    clearPing();
    if (ws) {
      try {
        ws.onopen = null;
        ws.onclose = null;
        ws.onerror = null;
        ws.onmessage = null;
        ws.close();
      } catch {
        /* ignore */
      }
    }
    ws = null;
    liveOpened = false;
    pendingHistory.clear();
  }

  function emitTick(symbol: string, quote: number, epoch: number, pipSize: number) {
    handlers.onTick({
      symbol,
      quote,
      epoch,
      pipSize,
      digit: lastDigit(quote, pipSize),
    });
  }

  function seedHistory(index: VolIndex, count: number): Tick[] {
    const ticks: Tick[] = [];
    let price = simPrices.get(index.symbol) ?? index.startPrice;
    const now = Math.floor(Date.now() / 1000);
    for (let i = count; i >= 1; i--) {
      price = stepPrice(index, price);
      ticks.push({
        symbol: index.symbol,
        quote: Number(price.toFixed(index.pipSize)),
        epoch: now - i * Math.round(index.intervalMs / 1000),
        pipSize: index.pipSize,
        digit: lastDigit(price, index.pipSize),
      });
    }
    simPrices.set(index.symbol, price);
    return ticks;
  }

  function startSimulator(reason: string, announce: boolean) {
    if (stopped) return;
    stopSim();
    simPrices = new Map(VOLATILITY_INDICES.map((s) => [s.symbol, s.startPrice]));
    for (const index of VOLATILITY_INDICES) {
      handlers.onHistory(index.symbol, seedHistory(index, TICK_CAP_SEED));
    }
    if (announce) setStatus("simulated", reason);

    const groups: Record<number, VolIndex[]> = {};
    for (const index of VOLATILITY_INDICES) {
      (groups[index.intervalMs] ??= []).push(index);
    }
    for (const [ms, list] of Object.entries(groups)) {
      const timer = setInterval(() => {
        if (stopped) return;
        const epoch = Math.floor(Date.now() / 1000);
        for (const index of list) {
          const next = stepPrice(index, simPrices.get(index.symbol) ?? index.startPrice);
          simPrices.set(index.symbol, next);
          emitTick(index.symbol, Number(next.toFixed(index.pipSize)), epoch, index.pipSize);
        }
      }, Number(ms));
      simTimers.push(timer);
    }
  }

  function handleMessage(raw: string) {
    let msg: WsMsg;
    try {
      msg = JSON.parse(raw) as WsMsg;
    } catch {
      return;
    }
    if (msg.error?.message) return;

    if (msg.msg_type === "tick" && msg.tick?.quote != null && msg.tick.symbol) {
      const symbol = msg.tick.symbol;
      const index = getIndex(symbol);
      const pip = msg.tick.pip_size ?? index.pipSize;
      emitTick(symbol, msg.tick.quote, msg.tick.epoch ?? Math.floor(Date.now() / 1000), pip);
      return;
    }

    if (msg.msg_type === "history" && msg.history?.prices && msg.history.times) {
      const symbol = msg.echo_req?.ticks_history;
      if (!symbol) return;
      const index = getIndex(symbol);
      const pip = msg.pip_size ?? index.pipSize;
      const prices = msg.history.prices;
      const times = msg.history.times;
      const ticks: Tick[] = [];
      for (let i = 0; i < prices.length; i++) {
        const quote = prices[i]!;
        const epoch = times[i] ?? 0;
        ticks.push({
          symbol,
          quote,
          epoch,
          pipSize: pip,
          digit: lastDigit(quote, pip),
        });
      }
      handlers.onHistory(symbol, ticks);
    }
  }

  function subscribeAll(socket: WebSocket) {
    socket.send(JSON.stringify({ forget_all: "ticks" }));
    for (const symbol of ALL_SYMBOLS) {
      socket.send(JSON.stringify({ ticks: symbol, subscribe: 1, req_id: reqSeq++ }));
    }
    const histId = reqSeq++;
    pendingHistory.set(histId, primary);
    socket.send(
      JSON.stringify({
        ticks_history: primary,
        adjust_start_time: 1,
        count: HISTORY_COUNT,
        end: "latest",
        start: 1,
        style: "ticks",
        req_id: histId,
      }),
    );
  }

  function attachSocket(socket: WebSocket) {
    ws = socket;
    liveOpened = true;
    stopSim();
    setStatus("live", "Streaming ticks from Deriv.");
    subscribeAll(socket);
    pingTimer = setInterval(() => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ ping: 1 }));
      }
    }, 20000);

    socket.onmessage = (ev) => handleMessage(String(ev.data));
    socket.onclose = () => {
      if (stopped) return;
      if (liveOpened) {
        liveOpened = false;
        startSimulator("Live stream dropped. Local volatility stream running.", true);
      }
    };
    socket.onerror = () => {
      /* onclose handles fallback */
    };
  }

  function tryLive(): Promise<boolean> {
    return new Promise((resolve) => {
      let settled = false;
      let attempt = 0;
      let candidate: WebSocket | null = null;

      const finish = (ok: boolean) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        if (!ok && candidate) {
          try {
            candidate.close();
          } catch {
            /* ignore */
          }
        }
        resolve(ok);
      };

      const timer = window.setTimeout(() => finish(false), LIVE_TIMEOUT_MS);

      const openNext = () => {
        if (settled || stopped) return;
        if (attempt >= ENDPOINTS.length) {
          finish(false);
          return;
        }
        const url = ENDPOINTS[attempt++]!;
        try {
          candidate = new WebSocket(url);
        } catch {
          openNext();
          return;
        }
        const current = candidate;
        current.onopen = () => {
          if (settled || stopped) {
            current.close();
            return;
          }
          attachSocket(current);
          finish(true);
        };
        current.onerror = () => {
          try {
            current.close();
          } catch {
            /* ignore */
          }
          if (!settled) openNext();
        };
      };

      openNext();
    });
  }

  async function connect() {
    if (stopped) return;
    closeWs();
    startSimulator("Streaming locally while the live Deriv feed is reached.", true);
    const ok = await tryLive();
    if (stopped) return;
    if (!ok) {
      setStatus(
        "simulated",
        "Could not reach Deriv from this network. Local stream is active.",
      );
    }
  }

  return {
    start(symbol: string) {
      primary = symbol;
      void connect();
    },
    setPrimary(symbol: string) {
      primary = symbol;
      if (ws && ws.readyState === WebSocket.OPEN) {
        const histId = reqSeq++;
        pendingHistory.set(histId, primary);
        ws.send(
          JSON.stringify({
            ticks_history: primary,
            adjust_start_time: 1,
            count: HISTORY_COUNT,
            end: "latest",
            start: 1,
            style: "ticks",
            req_id: histId,
          }),
        );
      }
    },
    retryLive() {
      void connect();
    },
    stop() {
      stopped = true;
      closeWs();
      stopSim();
    },
  };
}

function gaussian(): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function stepPrice(index: VolIndex, price: number): number {
  const dt = index.intervalMs / 1000 / (365.25 * 24 * 3600);
  const sigma = (index.volatility / 100) * Math.sqrt(dt);
  const shock = gaussian() * sigma;
  const next = price * Math.exp(shock - (sigma * sigma) / 2);
  return Math.max(next, 10 ** -index.pipSize);
}
