import { GROUPS, VOLATILITY_INDICES } from "@/lib/deriv/symbols";
import { cn } from "@/lib/utils";
import { useVoltStore } from "@/lib/store";

export function IndexRail() {
  const symbol = useVoltStore((s) => s.symbol);
  const setSymbol = useVoltStore((s) => s.setSymbol);
  const lastBySymbol = useVoltStore((s) => s.lastBySymbol);

  return (
    <>
      <div className="flex gap-2 overflow-x-auto px-4 py-3 lg:hidden">
        {VOLATILITY_INDICES.map((idx) => {
          const last = lastBySymbol[idx.symbol];
          const active = idx.symbol === symbol;
          return (
            <button
              key={idx.symbol}
              type="button"
              onClick={() => setSymbol(idx.symbol)}
              className={cn(
                "flex h-11 shrink-0 items-center gap-2 rounded-full border px-3.5 text-sm",
                active
                  ? "border-accent/40 bg-accent text-accent-fg"
                  : "border-border bg-elevated text-fg",
              )}
            >
              <span className="font-medium">{idx.short}</span>
              <span className="font-mono tabular-nums text-xs opacity-80">
                {last ? last.digit : "–"}
              </span>
            </button>
          );
        })}
      </div>

      <aside className="hidden w-[220px] shrink-0 flex-col border-r border-border lg:flex">
        {GROUPS.map((group) => (
          <div key={group.id} className="px-3 py-3">
            <p className="px-2 text-2xs font-medium uppercase tracking-[0.16em] text-subtle">
              {group.label}
            </p>
            <p className="mb-2 px-2 text-2xs text-subtle">{group.hint}</p>
            <ul className="flex flex-col gap-1">
              {VOLATILITY_INDICES.filter((i) => i.group === group.id).map((idx) => {
                const last = lastBySymbol[idx.symbol];
                const active = idx.symbol === symbol;
                return (
                  <li key={idx.symbol}>
                    <button
                      type="button"
                      onClick={() => setSymbol(idx.symbol)}
                      className={cn(
                        "flex h-11 w-full items-center gap-2 rounded-[var(--radius-md)] px-2.5 text-left",
                        active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/70 hover:text-fg",
                      )}
                    >
                      <span
                        className={cn(
                          "flex size-7 items-center justify-center rounded-[var(--radius-sm)] font-mono text-xs tabular-nums",
                          active ? "bg-accent text-accent-fg" : "bg-surface text-fg",
                        )}
                      >
                        {last ? last.digit : "–"}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium text-fg">{idx.short}</span>
                        <span className="block truncate text-2xs text-subtle">{idx.name}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </aside>
    </>
  );
}
