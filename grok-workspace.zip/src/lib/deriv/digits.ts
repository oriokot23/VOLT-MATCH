export type Tick = {
  symbol: string;
  quote: number;
  epoch: number;
  pipSize: number;
  digit: number;
};

export function lastDigit(quote: number, pipSize: number): number {
  const n = Math.max(0, Math.min(8, Math.round(pipSize)));
  const text = quote.toFixed(n);
  const char = text.charAt(text.length - 1);
  const d = Number(char);
  return Number.isFinite(d) ? d : 0;
}

export function formatQuote(quote: number, pipSize: number): { head: string; tail: string } {
  const n = Math.max(0, Math.min(8, Math.round(pipSize)));
  const text = quote.toFixed(n);
  return { head: text.slice(0, -1), tail: text.slice(-1) };
}

export function splitQuote(tick: Tick): { head: string; tail: string } {
  return formatQuote(tick.quote, tick.pipSize);
}
