import { useMemo } from "react";
import { analyze, scoreDigits } from "@/lib/analysis";
import type { Tick } from "@/lib/deriv/digits";
import { useVoltStore } from "@/lib/store";

const EMPTY: Tick[] = [];

export function usePrimaryAnalysis() {
  const symbol = useVoltStore((s) => s.symbol);
  const windowSize = useVoltStore((s) => s.windowSize);
  const strategy = useVoltStore((s) => s.strategy);
  const ticks = useVoltStore((s) => s.ticksBySymbol[symbol] ?? EMPTY);

  return useMemo(() => {
    const window = ticks.slice(-windowSize);
    const digits = window.map((t) => t.digit);
    const stats = analyze(digits);
    const signal = scoreDigits(stats, digits, strategy);
    const last = ticks[ticks.length - 1] ?? null;
    return { ticks, window, digits, stats, signal, last };
  }, [ticks, windowSize, strategy]);
}
