import { useEffect, useState } from "react";
import { Bar, BarChart, Cell, ReferenceLine, ResponsiveContainer, XAxis, YAxis } from "recharts";
import type { DigitStats, Signal } from "@/lib/analysis";

export function FreqChart({ stats, signal }: { stats: DigitStats; signal: Signal }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const data = stats.percents.map((pct, digit) => ({
    digit: String(digit),
    pct: Number(pct.toFixed(2)),
    pick: digit === signal.primary.digit,
  }));

  return (
    <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
      <div className="mb-2 flex items-end justify-between">
        <h3 className="text-sm font-medium text-fg">Frequency vs 10%</h3>
        <p className="text-xs text-subtle">{stats.chiLabel}</p>
      </div>
      <div className="h-40 w-full">
        {mounted ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
              <XAxis
                dataKey="digit"
                tick={{ fill: "var(--color-muted)", fontSize: 11, fontFamily: "var(--font-mono)" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "var(--color-subtle)", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
                domain={[0, "auto"]}
              />
              <ReferenceLine y={10} stroke="var(--color-border)" strokeDasharray="3 4" />
              <Bar dataKey="pct" radius={[4, 4, 0, 0]} maxBarSize={28}>
                {data.map((entry) => (
                  <Cell
                    key={entry.digit}
                    fill={entry.pick ? "var(--color-live)" : "var(--color-accent)"}
                    fillOpacity={entry.pick ? 0.9 : 0.35}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : null}
      </div>
    </section>
  );
}
