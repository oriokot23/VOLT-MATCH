import { create } from "zustand";
import type { Tick } from "@/lib/deriv/digits";
import { DEFAULT_SYMBOL } from "@/lib/deriv/symbols";
import type { FeedStatus } from "@/lib/deriv/feed";
import type { Strategy } from "@/lib/analysis";

export type Trade = {
  id: string;
  at: number;
  symbol: string;
  called: number;
  actual: number;
  won: boolean;
  stake: number;
  pnl: number;
  bank: number;
};

export type ArmedCall = {
  symbol: string;
  digit: number;
  stake: number;
} | null;

type Persist = {
  symbol: string;
  windowSize: number;
  strategy: Strategy;
  stake: number;
  bank: number;
};

const STORAGE_KEY = "voltmatch.v1";
const TICK_CAP = 1500;
const JOURNAL_CAP = 80;
const START_BANK = 1000;
const PAYOUT = 9.5;

const EMPTY_TICKS: Tick[] = [];

function loadPersist(): Partial<Persist> {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Persist;
  } catch {
    return {};
  }
}

function pushCap<T>(arr: T[], item: T, cap: number): T[] {
  if (arr.length < cap) return [...arr, item];
  const next = arr.slice(arr.length - cap + 1);
  next.push(item);
  return next;
}

export type VoltState = {
  symbol: string;
  windowSize: number;
  strategy: Strategy;
  stake: number;
  bank: number;
  payout: number;
  status: FeedStatus;
  ticksBySymbol: Record<string, Tick[]>;
  lastBySymbol: Record<string, Tick>;
  journal: Trade[];
  armed: ArmedCall;
  flashEpoch: number;
  briefing: string;
  briefingError: string;
  briefingBusy: boolean;
  setSymbol: (symbol: string) => void;
  setWindowSize: (n: number) => void;
  setStrategy: (s: Strategy) => void;
  setStake: (n: number) => void;
  setStatus: (status: FeedStatus) => void;
  ingestHistory: (symbol: string, ticks: Tick[]) => void;
  ingestTick: (tick: Tick) => void;
  arm: (digit: number) => void;
  disarm: () => void;
  resetBank: () => void;
  setBriefing: (text: string) => void;
  setBriefingError: (text: string) => void;
  setBriefingBusy: (busy: boolean) => void;
  persist: () => void;
};

export const useVoltStore = create<VoltState>((set, get) => ({
  symbol: DEFAULT_SYMBOL,
  windowSize: 100,
  strategy: "ensemble",
  stake: 10,
  bank: START_BANK,
  payout: PAYOUT,
  status: { mode: "connecting", detail: "Opening tick stream…" },
  ticksBySymbol: {},
  lastBySymbol: {},
  journal: [],
  armed: null,
  flashEpoch: 0,
  briefing: "",
  briefingError: "",
  briefingBusy: false,

  setSymbol: (symbol) => {
    set({ symbol, briefing: "", briefingError: "" });
    get().persist();
  },
  setWindowSize: (windowSize) => {
    set({ windowSize });
    get().persist();
  },
  setStrategy: (strategy) => {
    set({ strategy, briefing: "" });
    get().persist();
  },
  setStake: (stake) => {
    set({ stake });
    get().persist();
  },
  setStatus: (status) => set({ status }),
  ingestHistory: (symbol, ticks) =>
    set((s) => {
      const sliced = ticks.slice(-TICK_CAP);
      const last = sliced[sliced.length - 1];
      return {
        ticksBySymbol: { ...s.ticksBySymbol, [symbol]: sliced },
        lastBySymbol: last ? { ...s.lastBySymbol, [symbol]: last } : s.lastBySymbol,
      };
    }),
  ingestTick: (tick) =>
    set((s) => {
      const prev = s.ticksBySymbol[tick.symbol] ?? EMPTY_TICKS;
      const lastPrev = prev[prev.length - 1];
      if (lastPrev && lastPrev.epoch === tick.epoch && lastPrev.quote === tick.quote) {
        return s;
      }
      const nextTicks = pushCap(prev, tick, TICK_CAP);
      let bank = s.bank;
      let journal = s.journal;
      let armed = s.armed;
      let traded = false;
      if (armed && armed.symbol === tick.symbol) {
        const won = tick.digit === armed.digit;
        const pnl = won ? armed.stake * (s.payout - 1) : -armed.stake;
        bank = Math.max(0, bank + pnl);
        const trade: Trade = {
          id: `${tick.epoch}-${tick.symbol}-${armed.digit}`,
          at: Date.now(),
          symbol: tick.symbol,
          called: armed.digit,
          actual: tick.digit,
          won,
          stake: armed.stake,
          pnl,
          bank,
        };
        journal = pushCap(journal, trade, JOURNAL_CAP);
        armed = null;
        traded = true;
      }
      const next: Partial<VoltState> = {
        ticksBySymbol: { ...s.ticksBySymbol, [tick.symbol]: nextTicks },
        lastBySymbol: { ...s.lastBySymbol, [tick.symbol]: tick },
        flashEpoch: tick.symbol === s.symbol ? tick.epoch : s.flashEpoch,
        bank,
        journal,
        armed,
      };
      if (traded && typeof window !== "undefined") {
        try {
          const data = {
            symbol: s.symbol,
            windowSize: s.windowSize,
            strategy: s.strategy,
            stake: s.stake,
            bank,
          };
          localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch {
          /* ignore */
        }
      }
      return next;
    }),
  arm: (digit) => {
    const { symbol, stake, bank, armed } = get();
    if (armed) return;
    if (stake > bank) return;
    set({ armed: { symbol, digit, stake } });
  },
  disarm: () => set({ armed: null }),
  resetBank: () => {
    set({ bank: START_BANK, journal: [], armed: null });
    get().persist();
  },
  setBriefing: (briefing) => set({ briefing, briefingError: "" }),
  setBriefingError: (briefingError) => set({ briefingError }),
  setBriefingBusy: (briefingBusy) => set({ briefingBusy }),
  persist: () => {
    if (typeof window === "undefined") return;
    const s = get();
    const data: Persist = {
      symbol: s.symbol,
      windowSize: s.windowSize,
      strategy: s.strategy,
      stake: s.stake,
      bank: s.bank,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      /* ignore */
    }
  },
}));

export function hydrateVoltStore() {
  const p = loadPersist();
  if (!p.symbol && p.bank == null && p.windowSize == null) return;
  useVoltStore.setState({
    symbol: p.symbol ?? DEFAULT_SYMBOL,
    windowSize: p.windowSize ?? 100,
    strategy: p.strategy ?? "ensemble",
    stake: p.stake ?? 10,
    bank: p.bank ?? START_BANK,
  });
}

export function selectTicks(symbol: string) {
  return (s: VoltState) => s.ticksBySymbol[symbol] ?? EMPTY_TICKS;
}
