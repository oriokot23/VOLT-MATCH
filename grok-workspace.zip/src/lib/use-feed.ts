import { useEffect, useRef } from "react";
import { createFeed, type DerivFeed } from "@/lib/deriv/feed";
import { hydrateVoltStore, useVoltStore } from "@/lib/store";

export function useDerivFeed() {
  const feedRef = useRef<DerivFeed | null>(null);
  const symbol = useVoltStore((s) => s.symbol);
  const ingestTick = useVoltStore((s) => s.ingestTick);
  const ingestHistory = useVoltStore((s) => s.ingestHistory);
  const setStatus = useVoltStore((s) => s.setStatus);

  useEffect(() => {
    hydrateVoltStore();
    const feed = createFeed({
      onStatus: setStatus,
      onTick: ingestTick,
      onHistory: ingestHistory,
    });
    feedRef.current = feed;
    feed.start(useVoltStore.getState().symbol);
    return () => {
      feed.stop();
      feedRef.current = null;
    };
  }, [ingestHistory, ingestTick, setStatus]);

  useEffect(() => {
    feedRef.current?.setPrimary(symbol);
  }, [symbol]);

  return {
    retryLive: () => feedRef.current?.retryLive(),
  };
}
