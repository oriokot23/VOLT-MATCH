import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as array } from "../_libs/zod.mjs";
import { a as LoaderCircle, i as Radio, n as Target, r as RotateCcw } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { a as Bar, i as ReferenceLine, n as YAxis, o as Cell, r as XAxis, s as ResponsiveContainer, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DjkAk6dG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function lastDigit(quote, pipSize) {
	const n = Math.max(0, Math.min(8, Math.round(pipSize)));
	const text = quote.toFixed(n);
	const char = text.charAt(text.length - 1);
	const d = Number(char);
	return Number.isFinite(d) ? d : 0;
}
function formatQuote(quote, pipSize) {
	const n = Math.max(0, Math.min(8, Math.round(pipSize)));
	const text = quote.toFixed(n);
	return {
		head: text.slice(0, -1),
		tail: text.slice(-1)
	};
}
function splitQuote(tick) {
	return formatQuote(tick.quote, tick.pipSize);
}
var VOLATILITY_INDICES = [
	{
		symbol: "R_10",
		name: "Volatility 10",
		short: "V10",
		volatility: 10,
		intervalMs: 2e3,
		group: "2s",
		pipSize: 3,
		startPrice: 6842.315
	},
	{
		symbol: "R_25",
		name: "Volatility 25",
		short: "V25",
		volatility: 25,
		intervalMs: 2e3,
		group: "2s",
		pipSize: 3,
		startPrice: 4521.804
	},
	{
		symbol: "R_50",
		name: "Volatility 50",
		short: "V50",
		volatility: 50,
		intervalMs: 2e3,
		group: "2s",
		pipSize: 3,
		startPrice: 3188.472
	},
	{
		symbol: "R_75",
		name: "Volatility 75",
		short: "V75",
		volatility: 75,
		intervalMs: 2e3,
		group: "2s",
		pipSize: 4,
		startPrice: 187654.3214
	},
	{
		symbol: "R_100",
		name: "Volatility 100",
		short: "V100",
		volatility: 100,
		intervalMs: 2e3,
		group: "2s",
		pipSize: 2,
		startPrice: 1428.67
	},
	{
		symbol: "1HZ10V",
		name: "Volatility 10 (1s)",
		short: "V10 1s",
		volatility: 10,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 3,
		startPrice: 7912.448
	},
	{
		symbol: "1HZ15V",
		name: "Volatility 15 (1s)",
		short: "V15 1s",
		volatility: 15,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 3,
		startPrice: 6120.173
	},
	{
		symbol: "1HZ25V",
		name: "Volatility 25 (1s)",
		short: "V25 1s",
		volatility: 25,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 3,
		startPrice: 5088.926
	},
	{
		symbol: "1HZ30V",
		name: "Volatility 30 (1s)",
		short: "V30 1s",
		volatility: 30,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 3,
		startPrice: 4471.552
	},
	{
		symbol: "1HZ50V",
		name: "Volatility 50 (1s)",
		short: "V50 1s",
		volatility: 50,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 3,
		startPrice: 2894.107
	},
	{
		symbol: "1HZ75V",
		name: "Volatility 75 (1s)",
		short: "V75 1s",
		volatility: 75,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 4,
		startPrice: 96541.2287
	},
	{
		symbol: "1HZ90V",
		name: "Volatility 90 (1s)",
		short: "V90 1s",
		volatility: 90,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 2,
		startPrice: 2144.36
	},
	{
		symbol: "1HZ100V",
		name: "Volatility 100 (1s)",
		short: "V100 1s",
		volatility: 100,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 2,
		startPrice: 1337.42
	},
	{
		symbol: "1HZ150V",
		name: "Volatility 150 (1s)",
		short: "V150 1s",
		volatility: 150,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 2,
		startPrice: 988.15
	},
	{
		symbol: "1HZ250V",
		name: "Volatility 250 (1s)",
		short: "V250 1s",
		volatility: 250,
		intervalMs: 1e3,
		group: "1s",
		pipSize: 2,
		startPrice: 742.89
	}
];
var DEFAULT_SYMBOL = "1HZ100V";
var ALL_SYMBOLS = VOLATILITY_INDICES.map((s) => s.symbol);
var BY_SYMBOL = new Map(VOLATILITY_INDICES.map((s) => [s.symbol, s]));
function getIndex(symbol) {
	return BY_SYMBOL.get(symbol) ?? VOLATILITY_INDICES[12];
}
var GROUPS = [{
	id: "2s",
	label: "Standard",
	hint: "One tick every 2 seconds"
}, {
	id: "1s",
	label: "1-second",
	hint: "One tick every second"
}];
var ENDPOINTS = ["wss://ws.derivws.com/websockets/v3?app_id=1089", "wss://ws.binaryws.com/websockets/v3?app_id=1089"];
var LIVE_TIMEOUT_MS = 4500;
var HISTORY_COUNT = 800;
var TICK_CAP_SEED = 400;
function createFeed(handlers) {
	let stopped = false;
	let ws = null;
	let pingTimer = null;
	let simTimers = [];
	let primary = ALL_SYMBOLS[0];
	let simPrices = /* @__PURE__ */ new Map();
	let reqSeq = 1;
	let pendingHistory = /* @__PURE__ */ new Map();
	let liveOpened = false;
	function setStatus(mode, detail) {
		handlers.onStatus({
			mode,
			detail
		});
	}
	function clearPing() {
		if (pingTimer) {
			clearInterval(pingTimer);
			pingTimer = null;
		}
	}
	function stopSim() {
		for (const t of simTimers) clearInterval(t);
		simTimers = [];
	}
	function closeWs() {
		clearPing();
		if (ws) try {
			ws.onopen = null;
			ws.onclose = null;
			ws.onerror = null;
			ws.onmessage = null;
			ws.close();
		} catch {}
		ws = null;
		liveOpened = false;
		pendingHistory.clear();
	}
	function emitTick(symbol, quote, epoch, pipSize) {
		handlers.onTick({
			symbol,
			quote,
			epoch,
			pipSize,
			digit: lastDigit(quote, pipSize)
		});
	}
	function seedHistory(index, count) {
		const ticks = [];
		let price = simPrices.get(index.symbol) ?? index.startPrice;
		const now = Math.floor(Date.now() / 1e3);
		for (let i = count; i >= 1; i--) {
			price = stepPrice(index, price);
			ticks.push({
				symbol: index.symbol,
				quote: Number(price.toFixed(index.pipSize)),
				epoch: now - i * Math.round(index.intervalMs / 1e3),
				pipSize: index.pipSize,
				digit: lastDigit(price, index.pipSize)
			});
		}
		simPrices.set(index.symbol, price);
		return ticks;
	}
	function startSimulator(reason) {
		if (stopped) return;
		closeWs();
		stopSim();
		simPrices = new Map(VOLATILITY_INDICES.map((s) => [s.symbol, s.startPrice]));
		for (const index of VOLATILITY_INDICES) handlers.onHistory(index.symbol, seedHistory(index, TICK_CAP_SEED));
		setStatus("simulated", reason);
		const groups = {};
		for (const index of VOLATILITY_INDICES) (groups[index.intervalMs] ??= []).push(index);
		for (const [ms, list] of Object.entries(groups)) {
			const timer = setInterval(() => {
				if (stopped) return;
				const epoch = Math.floor(Date.now() / 1e3);
				for (const index of list) {
					const next = stepPrice(index, simPrices.get(index.symbol) ?? index.startPrice);
					simPrices.set(index.symbol, next);
					emitTick(index.symbol, Number(next.toFixed(index.pipSize)), epoch, index.pipSize);
				}
			}, Number(ms));
			simTimers.push(timer);
		}
	}
	function handleMessage(raw) {
		let msg;
		try {
			msg = JSON.parse(raw);
		} catch {
			return;
		}
		if (msg.error?.message) return;
		if (msg.msg_type === "tick" && msg.tick?.quote != null && msg.tick.symbol) {
			const symbol = msg.tick.symbol;
			const index = getIndex(symbol);
			const pip = msg.tick.pip_size ?? index.pipSize;
			emitTick(symbol, msg.tick.quote, msg.tick.epoch ?? Math.floor(Date.now() / 1e3), pip);
			return;
		}
		if (msg.msg_type === "history" && msg.history?.prices && msg.history.times) {
			const symbol = msg.echo_req?.ticks_history;
			if (!symbol) return;
			const index = getIndex(symbol);
			const pip = msg.pip_size ?? index.pipSize;
			const prices = msg.history.prices;
			const times = msg.history.times;
			const ticks = [];
			for (let i = 0; i < prices.length; i++) {
				const quote = prices[i];
				const epoch = times[i] ?? 0;
				ticks.push({
					symbol,
					quote,
					epoch,
					pipSize: pip,
					digit: lastDigit(quote, pip)
				});
			}
			handlers.onHistory(symbol, ticks);
		}
	}
	function subscribeAll(socket) {
		socket.send(JSON.stringify({ forget_all: "ticks" }));
		for (const symbol of ALL_SYMBOLS) socket.send(JSON.stringify({
			ticks: symbol,
			subscribe: 1,
			req_id: reqSeq++
		}));
		const histId = reqSeq++;
		pendingHistory.set(histId, primary);
		socket.send(JSON.stringify({
			ticks_history: primary,
			adjust_start_time: 1,
			count: HISTORY_COUNT,
			end: "latest",
			start: 1,
			style: "ticks",
			req_id: histId
		}));
	}
	function attachSocket(socket) {
		ws = socket;
		liveOpened = true;
		stopSim();
		setStatus("live", "Streaming ticks from Deriv.");
		subscribeAll(socket);
		pingTimer = setInterval(() => {
			if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ ping: 1 }));
		}, 2e4);
		socket.onmessage = (ev) => handleMessage(String(ev.data));
		socket.onclose = () => {
			if (stopped) return;
			if (liveOpened) {
				liveOpened = false;
				startSimulator("Live stream dropped. Local volatility stream running.");
			}
		};
		socket.onerror = () => {};
	}
	function tryLive() {
		return new Promise((resolve) => {
			let settled = false;
			let attempt = 0;
			let candidate = null;
			const finish = (ok) => {
				if (settled) return;
				settled = true;
				window.clearTimeout(timer);
				if (!ok && candidate) try {
					candidate.close();
				} catch {}
				resolve(ok);
			};
			const timer = window.setTimeout(() => finish(false), LIVE_TIMEOUT_MS);
			const openNext = () => {
				if (settled || stopped) return;
				if (attempt >= ENDPOINTS.length) {
					finish(false);
					return;
				}
				const url = ENDPOINTS[attempt++];
				try {
					candidate = new WebSocket(url);
				} catch {
					openNext();
					return;
				}
				const current = candidate;
				current.onopen = () => {
					if (settled || stopped) {
						current.close();
						return;
					}
					attachSocket(current);
					finish(true);
				};
				current.onerror = () => {
					try {
						current.close();
					} catch {}
					if (!settled) openNext();
				};
			};
			openNext();
		});
	}
	async function connect() {
		if (stopped) return;
		closeWs();
		stopSim();
		setStatus("connecting", "Opening Deriv tick stream…");
		const ok = await tryLive();
		if (stopped) return;
		if (!ok) startSimulator("Could not reach Deriv from this network. Local stream is active.");
	}
	return {
		start(symbol) {
			primary = symbol;
			connect();
		},
		setPrimary(symbol) {
			primary = symbol;
			if (ws && ws.readyState === WebSocket.OPEN) {
				const histId = reqSeq++;
				pendingHistory.set(histId, primary);
				ws.send(JSON.stringify({
					ticks_history: primary,
					adjust_start_time: 1,
					count: HISTORY_COUNT,
					end: "latest",
					start: 1,
					style: "ticks",
					req_id: histId
				}));
			}
		},
		retryLive() {
			connect();
		},
		stop() {
			stopped = true;
			closeWs();
			stopSim();
		}
	};
}
function gaussian() {
	let u = 0;
	let v = 0;
	while (u === 0) u = Math.random();
	while (v === 0) v = Math.random();
	return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
function stepPrice(index, price) {
	const dt = index.intervalMs / 1e3 / 31557600;
	const sigma = index.volatility / 100 * Math.sqrt(dt);
	const shock = gaussian() * sigma;
	const next = price * Math.exp(shock - sigma * sigma / 2);
	return Math.max(next, 10 ** -index.pipSize);
}
var STORAGE_KEY = "voltmatch.v1";
var TICK_CAP = 1500;
var JOURNAL_CAP = 80;
var START_BANK = 1e3;
var PAYOUT = 9.5;
var EMPTY_TICKS = [];
function loadPersist() {
	if (typeof window === "undefined") return {};
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return {};
		return JSON.parse(raw);
	} catch {
		return {};
	}
}
function pushCap(arr, item, cap) {
	if (arr.length < cap) return [...arr, item];
	const next = arr.slice(arr.length - cap + 1);
	next.push(item);
	return next;
}
var useVoltStore = create((set, get) => ({
	symbol: DEFAULT_SYMBOL,
	windowSize: 100,
	strategy: "ensemble",
	stake: 10,
	bank: START_BANK,
	payout: PAYOUT,
	status: {
		mode: "connecting",
		detail: "Opening tick stream…"
	},
	ticksBySymbol: {},
	lastBySymbol: {},
	journal: [],
	armed: null,
	flashEpoch: 0,
	briefing: "",
	briefingError: "",
	briefingBusy: false,
	setSymbol: (symbol) => {
		set({
			symbol,
			briefing: "",
			briefingError: ""
		});
		get().persist();
	},
	setWindowSize: (windowSize) => {
		set({ windowSize });
		get().persist();
	},
	setStrategy: (strategy) => {
		set({
			strategy,
			briefing: ""
		});
		get().persist();
	},
	setStake: (stake) => {
		set({ stake });
		get().persist();
	},
	setStatus: (status) => set({ status }),
	ingestHistory: (symbol, ticks) => set((s) => {
		const sliced = ticks.slice(-1500);
		const last = sliced[sliced.length - 1];
		return {
			ticksBySymbol: {
				...s.ticksBySymbol,
				[symbol]: sliced
			},
			lastBySymbol: last ? {
				...s.lastBySymbol,
				[symbol]: last
			} : s.lastBySymbol
		};
	}),
	ingestTick: (tick) => set((s) => {
		const prev = s.ticksBySymbol[tick.symbol] ?? EMPTY_TICKS;
		const lastPrev = prev[prev.length - 1];
		if (lastPrev && lastPrev.epoch === tick.epoch && lastPrev.quote === tick.quote) return s;
		const nextTicks = pushCap(prev, tick, TICK_CAP);
		let bank = s.bank;
		let journal = s.journal;
		let armed = s.armed;
		let traded = false;
		if (armed && armed.symbol === tick.symbol) {
			const won = tick.digit === armed.digit;
			const pnl = won ? armed.stake * (s.payout - 1) : -armed.stake;
			bank = Math.max(0, bank + pnl);
			const trade = {
				id: `${tick.epoch}-${tick.symbol}-${armed.digit}`,
				at: Date.now(),
				symbol: tick.symbol,
				called: armed.digit,
				actual: tick.digit,
				won,
				stake: armed.stake,
				pnl,
				bank
			};
			journal = pushCap(journal, trade, JOURNAL_CAP);
			armed = null;
			traded = true;
		}
		const next = {
			ticksBySymbol: {
				...s.ticksBySymbol,
				[tick.symbol]: nextTicks
			},
			lastBySymbol: {
				...s.lastBySymbol,
				[tick.symbol]: tick
			},
			flashEpoch: tick.symbol === s.symbol ? tick.epoch : s.flashEpoch,
			bank,
			journal,
			armed
		};
		if (traded && typeof window !== "undefined") try {
			const data = {
				symbol: s.symbol,
				windowSize: s.windowSize,
				strategy: s.strategy,
				stake: s.stake,
				bank
			};
			localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
		} catch {}
		return next;
	}),
	arm: (digit) => {
		const { symbol, stake, bank, armed } = get();
		if (armed) return;
		if (stake > bank) return;
		set({ armed: {
			symbol,
			digit,
			stake
		} });
	},
	disarm: () => set({ armed: null }),
	resetBank: () => {
		set({
			bank: START_BANK,
			journal: [],
			armed: null
		});
		get().persist();
	},
	setBriefing: (briefing) => set({
		briefing,
		briefingError: ""
	}),
	setBriefingError: (briefingError) => set({ briefingError }),
	setBriefingBusy: (briefingBusy) => set({ briefingBusy }),
	persist: () => {
		if (typeof window === "undefined") return;
		const s = get();
		const data = {
			symbol: s.symbol,
			windowSize: s.windowSize,
			strategy: s.strategy,
			stake: s.stake,
			bank: s.bank
		};
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
		} catch {}
	}
}));
function hydrateVoltStore() {
	const p = loadPersist();
	if (!p.symbol && p.bank == null && p.windowSize == null) return;
	useVoltStore.setState({
		symbol: p.symbol ?? "1HZ100V",
		windowSize: p.windowSize ?? 100,
		strategy: p.strategy ?? "ensemble",
		stake: p.stake ?? 10,
		bank: p.bank ?? START_BANK
	});
}
function useDerivFeed() {
	const feedRef = (0, import_react.useRef)(null);
	const symbol = useVoltStore((s) => s.symbol);
	const ingestTick = useVoltStore((s) => s.ingestTick);
	const ingestHistory = useVoltStore((s) => s.ingestHistory);
	const setStatus = useVoltStore((s) => s.setStatus);
	(0, import_react.useEffect)(() => {
		hydrateVoltStore();
		const feed = createFeed({
			onStatus: setStatus,
			onTick: ingestTick,
			onHistory: ingestHistory
		});
		feedRef.current = feed;
		feed.start(useVoltStore.getState().symbol);
		return () => {
			feed.stop();
			feedRef.current = null;
		};
	}, [
		ingestHistory,
		ingestTick,
		setStatus
	]);
	(0, import_react.useEffect)(() => {
		feedRef.current?.setPrimary(symbol);
	}, [symbol]);
	return { retryLive: () => feedRef.current?.retryLive() };
}
var STRATEGIES = [
	{
		id: "due",
		label: "Due",
		hint: "Under-printed and overdue digits"
	},
	{
		id: "hot",
		label: "Hot",
		hint: "Recently frequent digits"
	},
	{
		id: "markov",
		label: "Path",
		hint: "What usually follows the last digit"
	},
	{
		id: "ensemble",
		label: "Blend",
		hint: "Due + path + a touch of heat"
	}
];
var EMPTY_COUNTS = () => Array.from({ length: 10 }, () => 0);
function analyze(digits) {
	const counts = EMPTY_COUNTS();
	const lastSeen = Array.from({ length: 10 }, () => -1);
	const markov = Array.from({ length: 10 }, () => EMPTY_COUNTS());
	let even = 0;
	let over = 0;
	for (let i = 0; i < digits.length; i++) {
		const d = digits[i];
		if (d < 0 || d > 9) continue;
		counts[d] += 1;
		lastSeen[d] = i;
		if (d % 2 === 0) even += 1;
		if (d > 4) over += 1;
		if (i > 0) {
			const prev = digits[i - 1];
			if (prev >= 0 && prev <= 9) markov[prev][d] += 1;
		}
	}
	const n = digits.length;
	const expected = n / 10;
	const denom = Math.sqrt(Math.max(n * .1 * .9, 1e-9));
	const percents = counts.map((c) => n ? c / n * 100 : 0);
	const zScores = counts.map((c) => (c - expected) / denom);
	const gaps = lastSeen.map((idx) => n === 0 ? 0 : idx < 0 ? n : n - 1 - idx);
	const chiSquare = n === 0 ? 0 : counts.reduce((sum, c) => sum + (c - expected) ** 2 / Math.max(expected, 1e-9), 0);
	return {
		n,
		counts,
		percents,
		zScores,
		gaps,
		even,
		odd: n - even,
		over,
		under: n - over,
		chiSquare,
		chiLabel: chiLabel(chiSquare, n),
		markov
	};
}
function chiLabel(chi, n) {
	if (n < 50) return "Too little data";
	if (chi > 21.67) return "Skewed vs 10%";
	if (chi > 16.92) return "Mild skew";
	return "Close to uniform";
}
function softmax(values, temperature = .85) {
	const max = Math.max(...values);
	const exps = values.map((v) => Math.exp((v - max) / temperature));
	const sum = exps.reduce((a, b) => a + b, 0) || 1;
	return exps.map((e) => e / sum);
}
function dueScores(stats) {
	const gapDen = Math.sqrt(9);
	return stats.zScores.map((z, d) => {
		const under = -z;
		const overdue = (stats.gaps[d] - 10) / gapDen;
		return .58 * under + .42 * overdue;
	});
}
function hotScores(stats, recent) {
	const recCounts = EMPTY_COUNTS();
	for (const d of recent) if (d >= 0 && d <= 9) recCounts[d] += 1;
	const recN = Math.max(recent.length, 1);
	return stats.zScores.map((z, d) => .55 * z + .45 * (recCounts[d] / recN - .1) * 10);
}
function markovScores(stats, last) {
	if (last == null || last < 0 || last > 9) return Array.from({ length: 10 }, () => 0);
	const row = stats.markov[last];
	const rowN = row.reduce((a, b) => a + b, 0);
	if (rowN < 8) return Array.from({ length: 10 }, () => 0);
	return row.map((c) => (c / rowN - .1) * 8);
}
function blend(a, b, wa, wb) {
	return a.map((v, i) => wa * v + wb * (b[i] ?? 0));
}
function reasonList(digit, stats, last, strategy) {
	const reasons = [];
	const expected = stats.n / 10;
	const count = stats.counts[digit];
	const gap = stats.gaps[digit];
	const pct = stats.percents[digit];
	if (strategy === "due" || strategy === "ensemble") {
		if (count < expected - .4) reasons.push(`${digit} printed ${count}× vs ${expected.toFixed(1)} expected in this window (${pct.toFixed(1)}%).`);
		if (gap >= 16) reasons.push(`Last seen ${gap} ticks ago — overdue vs ~10 tick mean gap.`);
	}
	if (strategy === "hot" || strategy === "ensemble") {
		if (count > expected + .8) reasons.push(`${digit} is running hot at ${pct.toFixed(1)}% of the window.`);
	}
	if ((strategy === "markov" || strategy === "ensemble") && last != null) {
		const row = stats.markov[last];
		const rowN = row.reduce((a, b) => a + b, 0);
		if (rowN >= 8) {
			const p = row[digit] / rowN * 100;
			reasons.push(`After ${last}, ${digit} followed in ${row[digit]} of ${rowN} ticks (${p.toFixed(0)}%).`);
		}
	}
	if (reasons.length === 0) reasons.push(`Weights are close to the 10% base rate — no strong structure in this window.`);
	return reasons.slice(0, 3);
}
function scoreDigits(stats, digits, strategy) {
	const last = digits.length ? digits[digits.length - 1] : null;
	const recent = digits.slice(-20);
	const due = dueScores(stats);
	const hot = hotScores(stats, recent);
	const path = markovScores(stats, last);
	let raw;
	if (strategy === "due") raw = due;
	else if (strategy === "hot") raw = hot;
	else if (strategy === "markov") raw = path;
	else raw = blend(blend(due, path, .5, .3), hot, 1, .2);
	const weights = softmax(raw);
	const ranked = raw.map((score, digit) => ({
		digit,
		score,
		weight: weights[digit],
		reasons: reasonList(digit, stats, last, strategy)
	})).sort((a, b) => b.weight - a.weight);
	const primary = ranked[0];
	const second = ranked[1];
	const spread = primary.weight - second.weight;
	const skewed = stats.n >= 50 && stats.chiSquare > 16.92;
	let confidence = "Low";
	if (spread > .045 && skewed) confidence = "Moderate";
	else if (spread > .03 || skewed) confidence = "Mild";
	return {
		primary,
		ranked,
		confidence,
		confidenceNote: confidence === "Low" ? "Near-fair dice. Any lean is small and can vanish on the next tick." : confidence === "Mild" ? "A modest lean vs 10%. Treat it as a lens, not an edge." : "Window is off-uniform and the top digit separates. Still not a house-beating edge.",
		differsDigit: ranked[ranked.length - 1].digit
	};
}
function evenOddLean(stats) {
	if (!stats.n) return {
		evenPct: 50,
		oddPct: 50
	};
	return {
		evenPct: stats.even / stats.n * 100,
		oddPct: stats.odd / stats.n * 100
	};
}
function overUnderLean(stats) {
	if (!stats.n) return {
		overPct: 50,
		underPct: 50
	};
	return {
		overPct: stats.over / stats.n * 100,
		underPct: stats.under / stats.n * 100
	};
}
var EMPTY = [];
function usePrimaryAnalysis() {
	const symbol = useVoltStore((s) => s.symbol);
	const windowSize = useVoltStore((s) => s.windowSize);
	const strategy = useVoltStore((s) => s.strategy);
	const ticks = useVoltStore((s) => s.ticksBySymbol[symbol] ?? EMPTY);
	return (0, import_react.useMemo)(() => {
		const window = ticks.slice(-windowSize);
		const digits = window.map((t) => t.digit);
		const stats = analyze(digits);
		const signal = scoreDigits(stats, digits, strategy);
		const last = ticks[ticks.length - 1] ?? null;
		return {
			ticks,
			window,
			digits,
			stats,
			signal,
			last
		};
	}, [
		ticks,
		windowSize,
		strategy
	]);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium select-none transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-elevated text-fg border border-border hover:bg-surface",
			ghost: "text-muted hover:text-fg hover:bg-elevated",
			outline: "border border-border bg-transparent text-fg hover:bg-elevated"
		},
		size: {
			default: "h-11 rounded-[var(--radius-md)] px-4 text-sm",
			sm: "h-9 rounded-[var(--radius-sm)] px-3 text-xs",
			lg: "h-12 rounded-[var(--radius-md)] px-5 text-sm",
			icon: "size-11 rounded-[var(--radius-md)]"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Header({ onRetry }) {
	const status = useVoltStore((s) => s.status);
	const bank = useVoltStore((s) => s.bank);
	const live = status.mode === "live";
	const sim = status.mode === "simulated";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-3 border-b border-border px-4 py-3 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-sm font-semibold tracking-[0.18em] text-fg",
						children: "VOLTMATCH"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-muted sm:inline",
						children: "Digit Match AI"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-2xs text-subtle sm:text-xs",
					children: status.detail
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("inline-flex h-9 items-center gap-2 rounded-full border px-3 text-xs font-medium", live && "border-live/30 bg-live/10 text-live", sim && "border-border bg-elevated text-muted", status.mode === "connecting" && "border-border bg-elevated text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: cn("size-3.5", live && "live-dot text-live") }), live ? "Live Deriv" : sim ? "Local stream" : "Connecting"]
			}),
			sim ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: onRetry,
				className: "hidden sm:inline-flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Retry live"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden tabular-nums text-right sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xs uppercase tracking-wider text-subtle",
					children: "Paper bank"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-sm text-fg",
					children: formatMoney(bank)
				})]
			})
		]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex size-10 items-center justify-center rounded-[var(--radius-md)] border border-border bg-elevated",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 24 24",
			className: "size-5 text-accent",
			fill: "none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M4 18 L10 6 L13 12",
					stroke: "currentColor",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M13 12 L16 7 L20 18",
					stroke: "currentColor",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "16",
					cy: "7",
					r: "1.4",
					fill: "currentColor",
					className: "text-live"
				})
			]
		})
	});
}
function formatMoney(n) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 2
	}).format(n);
}
function IndexRail() {
	const symbol = useVoltStore((s) => s.symbol);
	const setSymbol = useVoltStore((s) => s.setSymbol);
	const lastBySymbol = useVoltStore((s) => s.lastBySymbol);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-2 overflow-x-auto px-4 py-3 lg:hidden",
		children: VOLATILITY_INDICES.map((idx) => {
			const last = lastBySymbol[idx.symbol];
			const active = idx.symbol === symbol;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setSymbol(idx.symbol),
				className: cn("flex h-11 shrink-0 items-center gap-2 rounded-full border px-3.5 text-sm", active ? "border-accent/40 bg-accent text-accent-fg" : "border-border bg-elevated text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: idx.short
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono tabular-nums text-xs opacity-80",
					children: last ? last.digit : "–"
				})]
			}, idx.symbol);
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "hidden w-[220px] shrink-0 flex-col border-r border-border lg:flex",
		children: GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 text-2xs font-medium uppercase tracking-[0.16em] text-subtle",
					children: group.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 px-2 text-2xs text-subtle",
					children: group.hint
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-1",
					children: VOLATILITY_INDICES.filter((i) => i.group === group.id).map((idx) => {
						const last = lastBySymbol[idx.symbol];
						const active = idx.symbol === symbol;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSymbol(idx.symbol),
							className: cn("flex h-11 w-full items-center gap-2 rounded-[var(--radius-md)] px-2.5 text-left", active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/70 hover:text-fg"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("flex size-7 items-center justify-center rounded-[var(--radius-sm)] font-mono text-xs tabular-nums", active ? "bg-accent text-accent-fg" : "bg-surface text-fg"),
								children: last ? last.digit : "–"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-medium text-fg",
									children: idx.short
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-2xs text-subtle",
									children: idx.name
								})]
							})]
						}) }, idx.symbol);
					})
				})
			]
		}, group.id))
	})] });
}
function QuoteStage({ tick, symbol }) {
	const index = getIndex(symbol);
	const parts = tick ? splitQuote(tick) : {
		head: "—",
		tail: ""
	};
	const sparkTicks = useVoltStore((s) => s.ticksBySymbol[symbol] ?? []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-2xs font-medium uppercase tracking-[0.16em] text-subtle",
				children: [
					index.group === "1s" ? "1s index" : "2s index",
					" · ",
					index.volatility,
					"% vol"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-lg font-medium tracking-tight text-fg",
				children: index.name
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, { ticks: sparkTicks.slice(-80) })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-xl tabular-nums text-muted sm:text-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: parts.head }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-live",
					children: parts.tail
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xs uppercase tracking-[0.16em] text-subtle",
					children: "Last digit"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("digit-pop font-mono text-5xl font-medium leading-none tabular-nums text-fg sm:text-5xl"),
					children: tick ? tick.digit : "–"
				}, tick?.epoch ?? "empty")]
			})]
		})]
	});
}
function Sparkline({ ticks }) {
	if (ticks.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-28" });
	const values = ticks.map((t) => t.quote);
	const min = Math.min(...values);
	const span = Math.max(...values) - min || 1;
	const w = 112;
	const h = 40;
	const d = values.map((v, i) => {
		const x = i / (values.length - 1) * w;
		const y = h - (v - min) / span * 36 - 2;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-10 w-28 text-live",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.4"
		})
	});
}
function DigitBoard({ stats, signal, lastDigit, selected, armedDigit, flashDigit, onSelect }) {
	const pick = signal.primary.digit;
	const maxPct = Math.max(12, ...stats.percents);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium text-fg",
					children: "Digit pad"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Tap a digit, then call the next tick"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tabular-nums text-subtle",
					children: [stats.n, " tick window"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-5 gap-2",
				children: Array.from({ length: 10 }, (_, digit) => {
					const pct = stats.percents[digit] ?? 0;
					const gap = stats.gaps[digit] ?? 0;
					const isPick = pick === digit;
					const isSel = selected === digit;
					const isArmed = armedDigit === digit;
					const isFlash = flashDigit === digit;
					const bar = Math.min(100, pct / maxPct * 100);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelect(digit),
						className: cn("relative flex h-[4.75rem] flex-col items-center justify-center overflow-hidden rounded-[var(--radius-md)] border bg-elevated px-1 pt-1", isSel || isArmed ? "border-accent text-fg" : "border-border text-fg", isPick && !isSel && "ring-1 ring-live/50", isFlash && "cell-flash"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xl font-medium tabular-nums leading-none",
								children: digit
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 font-mono text-2xs tabular-nums text-muted",
								children: [pct.toFixed(1), "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-2xs tabular-nums text-subtle",
								children: ["gap ", gap]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute inset-x-1 bottom-1 h-0.5 rounded-full bg-border",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("block h-full rounded-full", isPick ? "bg-live" : "bg-accent/70"),
									style: { width: `${bar}%` }
								})
							}),
							isPick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute right-1 top-1 text-2xs uppercase tracking-wide text-live",
								children: "AI"
							}) : null
						]
					}, digit);
				})
			}),
			lastDigit != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-muted",
				children: [
					"Last print ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-fg",
						children: lastDigit
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-subtle",
						children: [
							" · even/odd ",
							stats.even,
							"/",
							stats.odd,
							" · over/under ",
							stats.over,
							"/",
							stats.under
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "Waiting for ticks…"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var BriefingInput = object({
	name: string().max(80),
	symbol: string().max(20),
	strategy: string().max(20),
	window: number().int().min(10).max(2e3),
	lastDigit: number().int().min(0).max(9),
	pick: number().int().min(0).max(9),
	confidence: string().max(20),
	percents: array(number()).length(10),
	gaps: array(number()).length(10),
	chiLabel: string().max(40),
	recent: array(number().int().min(0).max(9)).max(60)
});
var requestBriefing = createServerFn({ method: "POST" }).validator((input) => BriefingInput.parse(input)).handler(createSsrRpc("31c1c2020cadfe9a7484ebb54b4c3570b96ddc4675bec251c52c6fa88e963852"));
function SignalDesk({ stats, signal, lastDigit, recent, selected, onSelect }) {
	const strategy = useVoltStore((s) => s.strategy);
	const setStrategy = useVoltStore((s) => s.setStrategy);
	const windowSize = useVoltStore((s) => s.windowSize);
	const setWindowSize = useVoltStore((s) => s.setWindowSize);
	const stake = useVoltStore((s) => s.stake);
	const setStake = useVoltStore((s) => s.setStake);
	const bank = useVoltStore((s) => s.bank);
	const payout = useVoltStore((s) => s.payout);
	const armed = useVoltStore((s) => s.armed);
	const arm = useVoltStore((s) => s.arm);
	const disarm = useVoltStore((s) => s.disarm);
	const symbol = useVoltStore((s) => s.symbol);
	const briefing = useVoltStore((s) => s.briefing);
	const briefingError = useVoltStore((s) => s.briefingError);
	const briefingBusy = useVoltStore((s) => s.briefingBusy);
	const setBriefing = useVoltStore((s) => s.setBriefing);
	const setBriefingError = useVoltStore((s) => s.setBriefingError);
	const setBriefingBusy = useVoltStore((s) => s.setBriefingBusy);
	const pick = selected ?? signal.primary.digit;
	const eo = evenOddLean(stats);
	const ou = overUnderLean(stats);
	const callReady = !armed && stake <= bank && lastDigit != null;
	async function brief() {
		if (briefingBusy || lastDigit == null) return;
		setBriefingBusy(true);
		try {
			const result = await requestBriefing({ data: {
				name: getIndex(symbol).name,
				symbol,
				strategy,
				window: windowSize,
				lastDigit,
				pick: signal.primary.digit,
				confidence: signal.confidence,
				percents: stats.percents,
				gaps: stats.gaps,
				chiLabel: stats.chiLabel,
				recent: recent.slice(-40)
			} });
			if (result.ok) setBriefing(result.text);
			else setBriefingError(result.error);
		} catch {
			setBriefingError("Briefing failed.");
		} finally {
			setBriefingBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xs font-medium uppercase tracking-[0.16em] text-subtle",
						children: "Match call"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-5xl font-medium leading-none tabular-nums text-fg",
							children: signal.primary.digit
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [signal.confidence, " confidence"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm tabular-nums text-live",
								children: [(signal.primary.weight * 100).toFixed(1), "% weight"]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted",
						children: signal.confidenceNote
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1.5 text-xs leading-relaxed text-fg",
						children: signal.primary.reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-l border-border pl-2 text-muted",
							children: r
						}, r))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-subtle",
						children: [
							"Also consider",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "font-mono text-fg",
								onClick: () => onSelect(signal.ranked[1].digit),
								children: signal.ranked[1]?.digit
							}),
							" ",
							"and",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "font-mono text-fg",
								onClick: () => onSelect(signal.ranked[2].digit),
								children: signal.ranked[2]?.digit
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-subtle",
								children: [" · differs lean ", signal.differsDigit]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xs font-medium uppercase tracking-[0.16em] text-subtle",
						children: "Paper desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "No Deriv wallet. Next tick settles the call."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Stake",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-11 w-full rounded-[var(--radius-md)] border border-border bg-elevated px-3 text-sm text-fg",
								value: stake,
								onChange: (e) => setStake(Number(e.target.value)),
								children: [
									1,
									2,
									5,
									10,
									25,
									50
								].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: n,
									children: ["$", n]
								}, n))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Bank",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "flex h-11 items-center rounded-[var(--radius-md)] border border-border bg-elevated px-3 font-mono text-sm tabular-nums",
								children: formatMoney(bank)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-3 w-full",
						disabled: !callReady,
						onClick: () => arm(pick),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, {}), armed ? `Armed on ${armed.digit}…` : `Call ${pick} next tick`]
					}),
					armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "mt-1 w-full",
						onClick: disarm,
						children: "Cancel"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-2xs text-subtle",
						children: [
							"Win returns ",
							payout.toFixed(2),
							"× stake. Typical Digit Match payout — house edge remains."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xs font-medium uppercase tracking-[0.16em] text-subtle",
						children: "Model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-1 rounded-[var(--radius-md)] bg-elevated p-1",
						children: STRATEGIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							title: s.hint,
							onClick: () => setStrategy(s.id),
							className: cn("h-9 rounded-[var(--radius-sm)] text-xs font-medium", strategy === s.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
							children: s.label
						}, s.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-1",
						children: [
							50,
							100,
							250,
							500
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setWindowSize(n),
							className: cn("h-9 flex-1 rounded-[var(--radius-sm)] border text-xs tabular-nums", windowSize === n ? "border-accent/40 bg-accent text-accent-fg" : "border-border bg-elevated text-muted"),
							children: n
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Even",
								value: `${eo.evenPct.toFixed(1)}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Odd",
								value: `${eo.oddPct.toFixed(1)}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Over 4",
								value: `${ou.overPct.toFixed(1)}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Under 5",
								value: `${ou.underPct.toFixed(1)}%`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-subtle",
						children: stats.chiLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "mt-3 w-full",
						disabled: briefingBusy || lastDigit == null,
						onClick: () => void brief(),
						children: [briefingBusy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null, briefingBusy ? "Reading the window…" : "Grok briefing"]
					}),
					briefing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted",
						children: briefing
					}) : null,
					briefingError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-loss",
						children: briefingError
					}) : null
				]
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-2xs uppercase tracking-[0.14em] text-subtle",
			children: label
		}), children]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[var(--radius-sm)] border border-border bg-elevated px-2.5 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-2xs text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums text-fg",
			children: value
		})]
	});
}
function Scanner({ onOpen }) {
	const lastBySymbol = useVoltStore((s) => s.lastBySymbol);
	const ticksBySymbol = useVoltStore((s) => s.ticksBySymbol);
	const active = useVoltStore((s) => s.symbol);
	const strategy = useVoltStore((s) => s.strategy);
	const rows = (0, import_react.useMemo)(() => {
		return VOLATILITY_INDICES.map((idx) => {
			const digits = (ticksBySymbol[idx.symbol] ?? []).slice(-100).map((t) => t.digit);
			const stats = analyze(digits);
			const signal = scoreDigits(stats, digits, strategy);
			const last = lastBySymbol[idx.symbol];
			const strength = Math.min(100, Math.round((signal.primary.weight - .1) * 900));
			return {
				idx,
				last,
				pick: signal.primary.digit,
				strength: Math.max(0, strength),
				chi: stats.chiLabel
			};
		});
	}, [
		lastBySymbol,
		ticksBySymbol,
		strategy
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex items-end justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium text-fg",
				children: "All volatility indices"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Live last digit and match lean across the full book"
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3",
			children: rows.map((row) => {
				const on = row.idx.symbol === active;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(row.idx.symbol),
					className: cn("flex items-center gap-3 rounded-[var(--radius-lg)] border px-3 py-2.5 text-left", on ? "border-accent/40 bg-elevated" : "border-border bg-elevated/60 hover:bg-elevated"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-11 items-center justify-center rounded-[var(--radius-md)] bg-surface font-mono text-xl tabular-nums text-fg",
							children: row.last ? row.last.digit : "–"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium text-fg",
								children: row.idx.short
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-2xs text-subtle",
								children: row.idx.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block font-mono text-sm tabular-nums text-live",
								children: ["→ ", row.pick]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-2xs tabular-nums text-subtle",
								children: row.strength
							})]
						})
					]
				}, row.idx.symbol);
			})
		})]
	});
}
function TickTape({ digits }) {
	const shown = digits.slice(-36);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium text-fg",
				children: "Tick tape"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-2xs text-subtle",
				children: "Newest on the right"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap justify-end gap-1 font-mono text-sm tabular-nums",
			children: shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: "Waiting for ticks…"
			}) : shown.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-8 items-center justify-center rounded-[var(--radius-sm)] bg-elevated", i === shown.length - 1 ? "bg-live/15 text-live" : "text-fg"),
				children: d
			}, `${i}-${d}`))
		})]
	});
}
function Journal() {
	const journal = useVoltStore((s) => s.journal);
	const resetBank = useVoltStore((s) => s.resetBank);
	const wins = journal.filter((t) => t.won).length;
	const recent = [...journal].reverse().slice(0, 12);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium text-fg",
				children: "Paper journal"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: journal.length === 0 ? "No settled calls yet" : `${wins}/${journal.length} hits · ${(wins / journal.length * 100).toFixed(0)}%`
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: resetBank,
				className: "text-xs text-muted hover:text-fg",
				children: "Reset bank"
			})]
		}), recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Arm a digit on the pad. The next tick on that index settles it."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-1.5",
			children: recent.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-2 rounded-[var(--radius-md)] border border-border bg-elevated px-3 py-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("font-mono tabular-nums", t.won ? "text-win" : "text-loss"),
						children: t.won ? "WIN" : "LOSS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 truncate text-muted",
						children: getIndex(t.symbol).short
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono tabular-nums text-fg",
						children: [
							t.called,
							"→",
							t.actual
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("font-mono tabular-nums", t.pnl >= 0 ? "text-win" : "text-loss"),
						children: [t.pnl >= 0 ? "+" : "", formatMoney(t.pnl)]
					})
				]
			}, t.id))
		})]
	});
}
function FreqChart({ stats, signal }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const data = stats.percents.map((pct, digit) => ({
		digit: String(digit),
		pct: Number(pct.toFixed(2)),
		pick: digit === signal.primary.digit
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium text-fg",
				children: "Frequency vs 10%"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: stats.chiLabel
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-40 w-full",
			children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
					data,
					margin: {
						top: 8,
						right: 4,
						left: -24,
						bottom: 0
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "digit",
							tick: {
								fill: "var(--color-muted)",
								fontSize: 11,
								fontFamily: "var(--font-mono)"
							},
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: {
								fill: "var(--color-subtle)",
								fontSize: 10
							},
							axisLine: false,
							tickLine: false,
							domain: [0, "auto"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
							y: 10,
							stroke: "var(--color-border)",
							strokeDasharray: "3 4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							dataKey: "pct",
							radius: [
								4,
								4,
								0,
								0
							],
							maxBarSize: 28,
							children: data.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
								fill: entry.pick ? "var(--color-live)" : "var(--color-accent)",
								fillOpacity: entry.pick ? .9 : .35
							}, entry.digit))
						})
					]
				})
			}) : null
		})]
	});
}
function VoltmatchApp() {
	const { retryLive } = useDerivFeed();
	const { stats, signal, last, digits } = usePrimaryAnalysis();
	const symbol = useVoltStore((s) => s.symbol);
	const setSymbol = useVoltStore((s) => s.setSymbol);
	const armed = useVoltStore((s) => s.armed);
	const flashEpoch = useVoltStore((s) => s.flashEpoch);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("desk");
	(0, import_react.useEffect)(() => {
		setSelected(null);
	}, [symbol]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
			if (e.key >= "0" && e.key <= "9") setSelected(Number(e.key));
			if (e.key === "Enter") useVoltStore.getState().arm(selected ?? signal.primary.digit);
			if (e.key === "Escape") useVoltStore.getState().disarm();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [selected, signal.primary.digit]);
	const pick = selected ?? signal.primary.digit;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col overflow-x-hidden bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, { onRetry: retryLive }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col lg:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexRail, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-w-0 flex-1 flex-col gap-3 p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1 rounded-[var(--radius-md)] bg-elevated p-1 lg:hidden",
						children: [
							["desk", "Desk"],
							["scanner", "Scanner"],
							["journal", "Journal"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setTab(id),
							className: cn("h-10 flex-1 rounded-[var(--radius-sm)] text-sm font-medium", tab === id ? "bg-accent text-accent-fg" : "text-muted"),
							children: label
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn(tab === "desk" ? "block" : "hidden", "lg:block"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 xl:grid-cols-[minmax(0,1fr)_320px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteStage, {
										tick: last,
										symbol
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DigitBoard, {
										stats,
										signal,
										lastDigit: last?.digit ?? null,
										selected: pick,
										armedDigit: armed?.digit ?? null,
										flashDigit: last && last.epoch === flashEpoch ? last.digit : null,
										onSelect: setSelected
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FreqChart, {
										stats,
										signal
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TickTape, { digits }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "hidden lg:block",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scanner, { onOpen: setSymbol })
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalDesk, {
								stats,
								signal,
								lastDigit: last?.digit ?? null,
								recent: digits,
								selected: pick,
								onSelect: setSelected
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn(tab === "scanner" ? "block" : "hidden", "lg:hidden"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scanner, { onOpen: (next) => {
							setSymbol(next);
							setTab("desk");
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn(tab === "journal" ? "block" : "hidden", "lg:block"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Journal, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-4 pt-2 text-2xs leading-relaxed text-subtle",
						children: "Voltmatch reads last digits from Deriv volatility ticks and ranks Digit Match calls with due, hot, path, and blend models. Synthetic indices are designed to be near-fair. Nothing here is a trading signal with positive expected value, financial advice, or a connection to a Deriv account. You can lose money on Digit Match."
					})
				]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoltmatchApp, {});
}
//#endregion
export { Home as component };
