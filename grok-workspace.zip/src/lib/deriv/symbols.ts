export type TickGroup = "2s" | "1s";

export type VolIndex = {
  symbol: string;
  name: string;
  short: string;
  volatility: number;
  intervalMs: number;
  group: TickGroup;
  pipSize: number;
  startPrice: number;
};

export const VOLATILITY_INDICES: VolIndex[] = [
  { symbol: "R_10", name: "Volatility 10", short: "V10", volatility: 10, intervalMs: 2000, group: "2s", pipSize: 3, startPrice: 6842.315 },
  { symbol: "R_25", name: "Volatility 25", short: "V25", volatility: 25, intervalMs: 2000, group: "2s", pipSize: 3, startPrice: 4521.804 },
  { symbol: "R_50", name: "Volatility 50", short: "V50", volatility: 50, intervalMs: 2000, group: "2s", pipSize: 3, startPrice: 3188.472 },
  { symbol: "R_75", name: "Volatility 75", short: "V75", volatility: 75, intervalMs: 2000, group: "2s", pipSize: 4, startPrice: 187654.3214 },
  { symbol: "R_100", name: "Volatility 100", short: "V100", volatility: 100, intervalMs: 2000, group: "2s", pipSize: 2, startPrice: 1428.67 },
  { symbol: "1HZ10V", name: "Volatility 10 (1s)", short: "V10 1s", volatility: 10, intervalMs: 1000, group: "1s", pipSize: 3, startPrice: 7912.448 },
  { symbol: "1HZ15V", name: "Volatility 15 (1s)", short: "V15 1s", volatility: 15, intervalMs: 1000, group: "1s", pipSize: 3, startPrice: 6120.173 },
  { symbol: "1HZ25V", name: "Volatility 25 (1s)", short: "V25 1s", volatility: 25, intervalMs: 1000, group: "1s", pipSize: 3, startPrice: 5088.926 },
  { symbol: "1HZ30V", name: "Volatility 30 (1s)", short: "V30 1s", volatility: 30, intervalMs: 1000, group: "1s", pipSize: 3, startPrice: 4471.552 },
  { symbol: "1HZ50V", name: "Volatility 50 (1s)", short: "V50 1s", volatility: 50, intervalMs: 1000, group: "1s", pipSize: 3, startPrice: 2894.107 },
  { symbol: "1HZ75V", name: "Volatility 75 (1s)", short: "V75 1s", volatility: 75, intervalMs: 1000, group: "1s", pipSize: 4, startPrice: 96541.2287 },
  { symbol: "1HZ90V", name: "Volatility 90 (1s)", short: "V90 1s", volatility: 90, intervalMs: 1000, group: "1s", pipSize: 2, startPrice: 2144.36 },
  { symbol: "1HZ100V", name: "Volatility 100 (1s)", short: "V100 1s", volatility: 100, intervalMs: 1000, group: "1s", pipSize: 2, startPrice: 1337.42 },
  { symbol: "1HZ150V", name: "Volatility 150 (1s)", short: "V150 1s", volatility: 150, intervalMs: 1000, group: "1s", pipSize: 2, startPrice: 988.15 },
  { symbol: "1HZ250V", name: "Volatility 250 (1s)", short: "V250 1s", volatility: 250, intervalMs: 1000, group: "1s", pipSize: 2, startPrice: 742.89 },
];

export const DEFAULT_SYMBOL = "1HZ100V";
export const ALL_SYMBOLS = VOLATILITY_INDICES.map((s) => s.symbol);

const BY_SYMBOL = new Map(VOLATILITY_INDICES.map((s) => [s.symbol, s]));

export function getIndex(symbol: string): VolIndex {
  return BY_SYMBOL.get(symbol) ?? VOLATILITY_INDICES[12]!;
}

export const GROUPS: { id: TickGroup; label: string; hint: string }[] = [
  { id: "2s", label: "Standard", hint: "One tick every 2 seconds" },
  { id: "1s", label: "1-second", hint: "One tick every second" },
];
