import type { ReactNode } from "react";
import { LoaderCircle, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { STRATEGIES, evenOddLean, overUnderLean, type DigitStats, type Signal, type Strategy } from "@/lib/analysis";
import { requestBriefing } from "@/lib/ai/briefing";
import { getIndex } from "@/lib/deriv/symbols";
import { useVoltStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { formatMoney } from "./header";

export function SignalDesk({
  stats,
  signal,
  lastDigit,
  recent,
  selected,
  onSelect,
}: {
  stats: DigitStats;
  signal: Signal;
  lastDigit: number | null;
  recent: number[];
  selected: number | null;
  onSelect: (digit: number) => void;
}) {
  const strategy = useVoltStore((s) => s.strategy);
  const setStrategy = useVoltStore((s) => s.setStrategy);
  const windowSize = useVoltStore((s) => s.windowSize);
  const setWindowSize = useVoltStore((s) => s.setWindowSize);
  const stake = useVoltStore((s) => s.stake);
  const setStake = useVoltStore((s) => s.setStake);
  const bank = useVoltStore((s) => s.bank);
  const payout = useVoltStore((s) => s.payout);
  const armed = useVoltStore((s) => s.armed);
  const arm = useVoltStore((s) => s.arm);
  const disarm = useVoltStore((s) => s.disarm);
  const symbol = useVoltStore((s) => s.symbol);
  const briefing = useVoltStore((s) => s.briefing);
  const briefingError = useVoltStore((s) => s.briefingError);
  const briefingBusy = useVoltStore((s) => s.briefingBusy);
  const setBriefing = useVoltStore((s) => s.setBriefing);
  const setBriefingError = useVoltStore((s) => s.setBriefingError);
  const setBriefingBusy = useVoltStore((s) => s.setBriefingBusy);

  const pick = selected ?? signal.primary.digit;
  const eo = evenOddLean(stats);
  const ou = overUnderLean(stats);
  const callReady = !armed && stake <= bank && lastDigit != null;

  async function brief() {
    if (briefingBusy || lastDigit == null) return;
    setBriefingBusy(true);
    try {
      const result = await requestBriefing({
        data: {
          name: getIndex(symbol).name,
          symbol,
          strategy,
          window: windowSize,
          lastDigit,
          pick: signal.primary.digit,
          confidence: signal.confidence,
          percents: stats.percents,
          gaps: stats.gaps,
          chiLabel: stats.chiLabel,
          recent: recent.slice(-40),
        },
      });
      if (result.ok) setBriefing(result.text);
      else setBriefingError(result.error);
    } catch {
      setBriefingError("Briefing failed.");
    } finally {
      setBriefingBusy(false);
    }
  }

  return (
    <aside className="flex flex-col gap-3">
      <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
        <p className="text-2xs font-medium uppercase tracking-[0.16em] text-subtle">Match call</p>
        <div className="mt-2 flex items-end justify-between gap-3">
          <p className="font-mono text-5xl font-medium leading-none tabular-nums text-fg">
            {signal.primary.digit}
          </p>
          <div className="text-right">
            <p className="text-xs text-muted">{signal.confidence} confidence</p>
            <p className="font-mono text-sm tabular-nums text-live">
              {(signal.primary.weight * 100).toFixed(1)}% weight
            </p>
          </div>
        </div>
        <p className="mt-3 text-xs leading-relaxed text-muted">{signal.confidenceNote}</p>
        <ul className="mt-3 space-y-1.5 text-xs leading-relaxed text-fg">
          {signal.primary.reasons.map((r) => (
            <li key={r} className="border-l border-border pl-2 text-muted">
              {r}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-subtle">
          Also consider{" "}
          <button type="button" className="font-mono text-fg" onClick={() => onSelect(signal.ranked[1]!.digit)}>
            {signal.ranked[1]?.digit}
          </button>{" "}
          and{" "}
          <button type="button" className="font-mono text-fg" onClick={() => onSelect(signal.ranked[2]!.digit)}>
            {signal.ranked[2]?.digit}
          </button>
          <span className="text-subtle"> · differs lean {signal.differsDigit}</span>
        </p>
      </section>

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
        <p className="text-2xs font-medium uppercase tracking-[0.16em] text-subtle">Paper desk</p>
        <p className="mt-1 text-xs text-muted">No Deriv wallet. Next tick settles the call.</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Field label="Stake">
            <select
              className="h-11 w-full rounded-[var(--radius-md)] border border-border bg-elevated px-3 text-sm text-fg"
              value={stake}
              onChange={(e) => setStake(Number(e.target.value))}
            >
              {[1, 2, 5, 10, 25, 50].map((n) => (
                <option key={n} value={n}>
                  ${n}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Bank">
            <p className="flex h-11 items-center rounded-[var(--radius-md)] border border-border bg-elevated px-3 font-mono text-sm tabular-nums">
              {formatMoney(bank)}
            </p>
          </Field>
        </div>
        <Button
          className="mt-3 w-full"
          disabled={!callReady}
          onClick={() => arm(pick)}
        >
          <Target />
          {armed ? `Armed on ${armed.digit}…` : `Call ${pick} next tick`}
        </Button>
        {armed ? (
          <Button variant="ghost" className="mt-1 w-full" onClick={disarm}>
            Cancel
          </Button>
        ) : null}
        <p className="mt-2 text-2xs text-subtle">
          Win returns {payout.toFixed(2)}× stake. Typical Digit Match payout — house edge remains.
        </p>
      </section>

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4 sm:p-5">
        <p className="text-2xs font-medium uppercase tracking-[0.16em] text-subtle">Model</p>
        <div className="mt-3 grid grid-cols-2 gap-1 rounded-[var(--radius-md)] bg-elevated p-1">
          {STRATEGIES.map((s) => (
            <button
              key={s.id}
              type="button"
              title={s.hint}
              onClick={() => setStrategy(s.id as Strategy)}
              className={cn(
                "h-9 rounded-[var(--radius-sm)] text-xs font-medium",
                strategy === s.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
              )}
            >
              {s.label}
            </button>
          ))}
        </div>
        <div className="mt-3 flex gap-1">
          {[50, 100, 250, 500].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setWindowSize(n)}
              className={cn(
                "h-9 flex-1 rounded-[var(--radius-sm)] border text-xs tabular-nums",
                windowSize === n
                  ? "border-accent/40 bg-accent text-accent-fg"
                  : "border-border bg-elevated text-muted",
              )}
            >
              {n}
            </button>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
          <Stat label="Even" value={`${eo.evenPct.toFixed(1)}%`} />
          <Stat label="Odd" value={`${eo.oddPct.toFixed(1)}%`} />
          <Stat label="Over 4" value={`${ou.overPct.toFixed(1)}%`} />
          <Stat label="Under 5" value={`${ou.underPct.toFixed(1)}%`} />
        </div>
        <p className="mt-3 text-xs text-subtle">{stats.chiLabel}</p>
        <Button
          variant="outline"
          size="sm"
          className="mt-3 w-full"
          disabled={briefingBusy || lastDigit == null}
          onClick={() => void brief()}
        >
          {briefingBusy ? <LoaderCircle className="animate-spin" /> : null}
          {briefingBusy ? "Reading the window…" : "Grok briefing"}
        </Button>
        {briefing ? <p className="mt-3 text-xs leading-relaxed text-muted">{briefing}</p> : null}
        {briefingError ? <p className="mt-3 text-xs text-loss">{briefingError}</p> : null}
      </section>
    </aside>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-2xs uppercase tracking-[0.14em] text-subtle">{label}</span>
      {children}
    </label>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[var(--radius-sm)] border border-border bg-elevated px-2.5 py-2">
      <p className="text-2xs text-subtle">{label}</p>
      <p className="font-mono text-sm tabular-nums text-fg">{value}</p>
    </div>
  );
}
